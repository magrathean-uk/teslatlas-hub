// SPDX-License-Identifier: AGPL-3.0-only

import AppKit
import Darwin
import Foundation

enum HubRelease {
    static let fallbackVersion = "2026.36.1"
    static let sourceRepository = "https://github.com/magrathean-uk/teslatlas-hub"
    static let licenceExpression = "AGPL-3.0-only"
    static var bundledVersion: String {
        guard let value = Bundle.main.object(forInfoDictionaryKey: "TeslatlasHubVersion") as? String,
              !value.isEmpty,
              !value.contains("$(") else { return fallbackVersion }
        return value
    }
    static var bundledSourceCommit: String? {
        guard let value = Bundle.main.object(forInfoDictionaryKey: "TeslatlasHubSourceCommit") as? String,
              isExactSourceCommit(value) else { return nil }
        return value
    }

    static func isExactSourceCommit(_ value: String) -> Bool {
        value.range(
            of: #"^[0-9a-f]{40}$"#,
            options: .regularExpression
        ) != nil
    }

    static func correspondingSourceURL(for commit: String? = bundledSourceCommit) -> URL? {
        guard let commit, isExactSourceCommit(commit) else { return nil }
        return URL(string: "\(sourceRepository)/tree/\(commit)")
    }

    static func licenceURL(for version: String = bundledVersion) -> URL? {
        guard version.range(
            of: #"^[0-9]+\.[0-9]+\.[0-9]+(?:-[0-9A-Za-z.-]+)?$"#,
            options: .regularExpression
        ) != nil else { return nil }
        return URL(string: "\(sourceRepository)/blob/v\(version)/LICENSE")
    }
}

enum HubShareRedactor {
    private static let replacements: [(pattern: String, template: String)] = [
        ("\u{001B}\\[[0-?]*[ -/]*[@-~]", ""),
        ("[\u{0000}-\u{0008}\u{000B}\u{000C}\u{000E}-\u{001F}\u{007F}]", ""),
        (#"(?i)(authorization\s*[:=]\s*(?:bearer|basic)\s+)[^\s,;]+"#, "$1[redacted]"),
        (#"(?i)(\b(?:access_?token|refresh_?token|ingest_?token|pairing_?token|device_?token|token|client_?secret|api_?key|private_?key|encryption_?key|password|authorization_?code|oauth_?code)\b\s*[\"']?\s*[:=]\s*[\"']?)[^\"'\s,&;}]+"#, "$1[redacted]"),
        (#"(?i)([?&](?:access_token|refresh_token|client_secret|code|state|nonce)=)[^&#\s]+"#, "$1[redacted]"),
        (#"(?i)((?:postgres(?:ql)?|https?)://[^/\s:@]+:)[^@/\s]+(@)"#, "$1[redacted]$2"),
        (#"(?i)(\"(?:display_?name|vehicle_?name)\"\s*:\s*)\"[^\"]*\""#, "$1\"[redacted-name]\""),
        (#"(?i)(\b(?:display_?name|vehicle_?name)\b\s*=\s*)(?:\"[^\"]*\"|[^\s,;]+)"#, "$1[redacted-name]"),
        (#"(?i)(\b(?:vehicle_?id|source_?car_?id|selected_?car_?id|car_?id|tesla_?eid)\b\s*[\"']?\s*[:=]\s*[\"']?)-?\d+(?![a-z0-9-])"#, "$1[redacted-id]"),
        (#"(?i)(\b(?:latitude|longitude|lat|lon)\b\s*[\"']?\s*[:=]\s*[\"']?)-?\d+(?:\.\d+)?"#, "$1[redacted-location]"),
        (#"\beyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\b"#, "[redacted-jwt]"),
        (#"(?i)\b[0-9a-f]{8}-(?:[0-9a-f]{4}-){3}[0-9a-f]{12}\b"#, "[redacted-id]"),
        (#"(?i)\b[0-9A-HJ-NPR-Z]{17}\b"#, "[redacted-vin]"),
        (#"(?i)\b[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,63}\b"#, "[redacted-email]"),
        (#"\b(?:10(?:\.\d{1,3}){3}|192\.168(?:\.\d{1,3}){2}|172\.(?:1[6-9]|2\d|3[01])(?:\.\d{1,3}){2})\b"#, "[redacted-private-ip]"),
        (#"(?<!\d)(?!127\.)(?:(?:25[0-5]|2[0-4]\d|1?\d?\d)\.){3}(?:25[0-5]|2[0-4]\d|1?\d?\d)(?!\d)"#, "[redacted-ip]"),
        (#"(?i)\[(?:(?:f[cd][0-9a-f]{2}|fe[89ab][0-9a-f]):[0-9a-f:.]+|::1)(?:%[a-z0-9_.-]+)?\](?::\d{1,5})?"#, "[redacted-private-ip]"),
        (#"(?i)\[[0-9a-f]*:[0-9a-f:.]+(?:%[a-z0-9_.-]+)?\](?::\d{1,5})?"#, "[redacted-ip]"),
        (#"(?i)(?<![0-9a-f:])(?:(?:f[cd][0-9a-f]{2}|fe[89ab][0-9a-f]):[0-9a-f:.]+|::1)(?:%[a-z0-9_.-]+)?(?![0-9a-f:])"#, "[redacted-private-ip]")
    ]
    private static let compiledReplacements: [(expression: NSRegularExpression, template: String)] =
        replacements.compactMap { replacement in
            guard let expression = try? NSRegularExpression(pattern: replacement.pattern) else {
                return nil
            }
            return (expression: expression, template: replacement.template)
        }

    static func redact(_ text: String, homeDirectory: String = NSHomeDirectory()) -> String {
        var redacted = homeDirectory.isEmpty
            ? text
            : text.replacingOccurrences(of: homeDirectory, with: "~")
        for replacement in compiledReplacements {
            let range = NSRange(redacted.startIndex..<redacted.endIndex, in: redacted)
            redacted = replacement.expression.stringByReplacingMatches(
                in: redacted,
                range: range,
                withTemplate: replacement.template
            )
        }
        return redacted
    }
}

enum HubHealth: Equatable {
    case running
    case stopped
    case needsInstall
    case degraded

    var title: String {
        switch self {
        case .running: return "Hub is running"
        case .stopped: return "Hub is stopped"
        case .needsInstall: return "Setup required"
        case .degraded: return "Attention needed"
        }
    }

    var color: NSColor {
        switch self {
        case .running: return .systemGreen
        case .stopped: return .systemOrange
        case .needsInstall: return .systemBlue
        case .degraded: return .systemRed
        }
    }
}

struct HubActivity {
    let message: String
    let age: String
    let color: NSColor
}

struct HubSetupInvocation: Equatable {
    let arguments: [String]
    let standardInput: String
}

struct HubFleetSetupCredentials: Equatable {
    let accessToken: String
    let refreshToken: String
    let clientID: String
    let region: String
    let expiresInSeconds: Int64
}

struct HubTeslaMateCompatibility: Equatable {
    let compatible: Bool
    let message: String
    let reasonCode: String
    let requiredVersion: String
}

struct HubMigrationProgress: Equatable {
    let completedRows: UInt64
    let totalRows: UInt64
    let phase: String?
}

private struct HubMigrationProgressPayload: Decodable {
    let event: String
    let completedRows: UInt64
    let totalRows: UInt64
    let phase: String?
}

private final class HubMigrationProgressDiagnostics {
    private let processStartedAt = Date()
    private let lock = NSLock()
    private var activePhase: String?
    private var phaseStartedAt: Date?
    private var finished = false

    func received(_ progress: HubMigrationProgress) {
        guard let nextPhase = progress.phase else { return }
        let now = Date()
        var completedPhase: (name: String, duration: TimeInterval)?
        var startedPhase: String?
        lock.lock()
        if !finished, nextPhase != activePhase {
            if let activePhase, let phaseStartedAt {
                completedPhase = (activePhase, now.timeIntervalSince(phaseStartedAt))
            }
            activePhase = nextPhase
            phaseStartedAt = now
            startedPhase = nextPhase
        }
        lock.unlock()
        if let completedPhase {
            Self.logPhaseCompleted(completedPhase.name, duration: completedPhase.duration)
        }
        if let startedPhase {
            HubAppLog.shared.record("import.phase.started", category: "teslamate_import",
                                    fields: ["phase": startedPhase])
        }
    }

    func finish() -> [String: String] {
        let now = Date()
        var completedPhase: (name: String, duration: TimeInterval)?
        lock.lock()
        if !finished {
            finished = true
            if let activePhase, let phaseStartedAt {
                completedPhase = (activePhase, now.timeIntervalSince(phaseStartedAt))
            }
            activePhase = nil
            phaseStartedAt = nil
        }
        lock.unlock()
        if let completedPhase {
            Self.logPhaseCompleted(completedPhase.name, duration: completedPhase.duration)
        }
        return ["duration_ms": String(Int(now.timeIntervalSince(processStartedAt) * 1_000))]
    }

    private static func logPhaseCompleted(_ phase: String, duration: TimeInterval) {
        HubAppLog.shared.record("import.phase.completed", category: "teslamate_import", fields: [
            "phase": phase,
            "duration_ms": String(Int(duration * 1_000))
        ])
    }
}

private final class HubMigrationProgressDelivery {
    private let lock = NSLock()
    private var active = true

    func cancel() {
        lock.lock()
        active = false
        lock.unlock()
    }

    func deliver(_ progress: HubMigrationProgress,
                 to callback: @escaping (HubMigrationProgress) -> Void) {
        lock.lock()
        guard active else {
            lock.unlock()
            return
        }
        DispatchQueue.main.async {
            callback(progress)
        }
        lock.unlock()
    }
}

struct HubOnboardingCheck: Equatable {
    let title: String
    let detail: String
    let passed: Bool
}

enum HubAccountProvider: String, Equatable {
    case legacy
    case fleet

    var displayName: String {
        switch self {
        case .legacy: return "Legacy token"
        case .fleet: return "Fleet API"
        }
    }
}

enum HubMigrationHandoverPhase: String, Codable, Equatable {
    case importing
    case awaitingVerification = "awaiting_verification"
    case awaitingHandover = "awaiting_handover"
}

private struct HubMigrationHandoverState: Codable {
    var phase: HubMigrationHandoverPhase
    let previousIntervalSeconds: Int
    let previousProvider: String?

    init(phase: HubMigrationHandoverPhase,
         previousIntervalSeconds: Int,
         previousProvider: String? = nil) {
        self.phase = phase
        self.previousIntervalSeconds = previousIntervalSeconds
        self.previousProvider = previousProvider
    }
}

private struct HubCollectorLeaseWitness: Decodable {
    let instanceId: UUID
    let startedAtMs: Int64
    let heartbeatAtMs: Int64
    let leaseUntilMs: Int64

    var isCoherent: Bool {
        startedAtMs >= 0
            && heartbeatAtMs >= startedAtMs
            && leaseUntilMs > heartbeatAtMs
    }
}

private struct HubStartupStatusDocument: Decodable {
    let status: String
    let ready: Bool
    let collector: HubCollectorLeaseWitness?
}

private enum HubCollectorLeaseBaseline {
    case observed(UUID?)
    case unavailable
}

enum HubVehicleControl: String, CaseIterable, Equatable {
    case wake
    case climateStart = "climate-start"
    case climateStop = "climate-stop"
    case lock
    case unlock
    case flashLights = "flash-lights"
    case honkHorn = "honk-horn"

    var title: String {
        switch self {
        case .wake: return "Wake Vehicle"
        case .climateStart: return "Start Climate"
        case .climateStop: return "Stop Climate"
        case .lock: return "Lock Doors"
        case .unlock: return "Unlock Doors"
        case .flashLights: return "Flash Lights"
        case .honkHorn: return "Honk Horn"
        }
    }

    var acceptedMessage: String {
        switch self {
        case .wake: return "Check the vehicle to confirm it woke."
        case .climateStart, .climateStop: return "Check the vehicle to confirm the climate changed."
        case .lock, .unlock: return "Check the vehicle to confirm the doors changed."
        case .flashLights: return "The flash-lights command was accepted."
        case .honkHorn: return "The honk-horn command was accepted."
        }
    }
}

struct HubControlVehicle: Equatable {
    let id: UUID
    let displayName: String
    let status: String
}

struct HubSnapshot {
    var health: HubHealth
    var service: String
    var account: String
    var provider: HubAccountProvider?
    var vehicleName: String
    var vehicle: String
    var controlVehicleID: UUID?
    var controlVehicles: [HubControlVehicle]
    var database: String
    var activity: [HubActivity]
    var version: String
    var dataDirectory: URL?
    var diagnosticLines: [String]

    var accountDisplay: String {
        guard account == "Connected", let provider else { return account }
        return "\(account) · \(provider.displayName)"
    }

    static let previewRunning = HubSnapshot(
        health: .running,
        service: "Active",
        account: "Connected",
        provider: .fleet,
        vehicleName: "Aurora",
        vehicle: "Model 3 Long Range · Parked · 78% · Home",
        controlVehicleID: UUID(uuidString: "B4C070D1-4C7C-4E01-BD5D-AC56F42A77B5"),
        controlVehicles: [
            HubControlVehicle(
                id: UUID(uuidString: "B4C070D1-4C7C-4E01-BD5D-AC56F42A77B5")!,
                displayName: "Aurora",
                status: "Model 3 Long Range · Parked · 78% · Home"
            ),
            HubControlVehicle(
                id: UUID(uuidString: "FB25AA4A-A719-4575-8BB1-02D4524F2571")!,
                displayName: "Comet",
                status: "Model Y Performance · Asleep · 54%"
            )
        ],
        database: "teslatlas.sqlite · 3.51 GB (imported)",
        activity: [
            HubActivity(message: "Imported TeslaMate history", age: "just now", color: .systemGreen)
        ],
        version: HubRelease.fallbackVersion,
        dataDirectory: URL(fileURLWithPath: NSHomeDirectory()).appendingPathComponent("Library/Application Support/Teslatlas Hub"),
        diagnosticLines: [
            "Preview mode: no process or launchctl mutation",
            "Service: Installed and running",
            "Account: Connected",
            "Vehicle: Model 3 · offline",
            "Database: Healthy · 18,426 records"
        ]
    )

    static let firstRun = HubSnapshot(
        health: .needsInstall,
        service: "Not installed",
        account: "Not configured",
        provider: nil,
        vehicleName: "Vehicle",
        vehicle: "No configured vehicle",
        controlVehicleID: nil,
        controlVehicles: [],
        database: "Waiting for setup or import",
        activity: [],
        version: HubRelease.fallbackVersion,
        dataDirectory: URL(fileURLWithPath: NSHomeDirectory()).appendingPathComponent("Library/Application Support/Teslatlas Hub/data"),
        diagnosticLines: ["Hub has not been configured or installed."]
    )
}

enum HubActionError: LocalizedError {
    case preview
    case missingResource(String)
    case untrustedInstaller(String)
    case commandFailed(String)
    case commandExited(Int32, String)
    case commandTimedOut

    var errorDescription: String? {
        switch self {
        case .preview:
            return "Preview mode is read-only. No process, installer, or launchctl action was run."
        case let .missingResource(name):
            return "Embedded resource is missing: \(name)"
        case let .untrustedInstaller(reason):
            return "Installer trust check failed: \(reason)"
        case let .commandFailed(message):
            return message
        case let .commandExited(_, message):
            return message
        case .commandTimedOut:
            return "Hub command timed out."
        }
    }
}

protocol HubCommandRunning {
    func run(arguments: [String], completion: @escaping (Result<String, Error>) -> Void)
    func run(arguments: [String], stdin: String, completion: @escaping (Result<String, Error>) -> Void)
    func run(arguments: [String],
             onOutputLine: @escaping (String) -> Void,
             completion: @escaping (Result<String, Error>) -> Void)
}

extension HubCommandRunning {
    func run(arguments: [String], stdin: String, completion: @escaping (Result<String, Error>) -> Void) {
        run(arguments: arguments, completion: completion)
    }

    func run(arguments: [String],
             onOutputLine: @escaping (String) -> Void,
             completion: @escaping (Result<String, Error>) -> Void) {
        run(arguments: arguments, completion: completion)
    }
}

final class BoundedProcessOutput {
    private let maximumBytes: Int
    private var retained = Data()
    private let lock = NSLock()

    init(maximumBytes: Int) {
        self.maximumBytes = maximumBytes
    }

    func append(_ chunk: Data) {
        guard maximumBytes > 0, !chunk.isEmpty else { return }
        lock.lock()
        defer { lock.unlock() }
        if chunk.count >= maximumBytes {
            retained = Data(chunk.suffix(maximumBytes))
            return
        }
        let overflow = retained.count + chunk.count - maximumBytes
        if overflow > 0 {
            retained.removeFirst(overflow)
        }
        retained.append(chunk)
    }

    func snapshot() -> Data {
        lock.lock()
        defer { lock.unlock() }
        return retained
    }
}

private final class ProcessOutputLineCallbackGate {
    private let lock = NSLock()
    private var callback: ((String) -> Void)?

    init(callback: ((String) -> Void)?) {
        self.callback = callback
    }

    var isActive: Bool {
        lock.lock()
        defer { lock.unlock() }
        return callback != nil
    }

    func emit(_ line: String) {
        lock.lock()
        let callback = callback
        lock.unlock()
        callback?(line)
    }

    func cancel() {
        lock.lock()
        callback = nil
        lock.unlock()
    }
}

private final class ProcessOutputLineDecoder {
    private static let maximumLineBytes = 64 * 1024

    private var bytes: [UInt8] = []
    private var discardingOversizedLine = false
    private let callbackGate: ProcessOutputLineCallbackGate

    init(callbackGate: ProcessOutputLineCallbackGate) {
        self.callbackGate = callbackGate
        bytes.reserveCapacity(1_024)
    }

    func append(_ chunk: Data) {
        guard callbackGate.isActive else { return }
        for byte in chunk {
            if discardingOversizedLine {
                if byte == 0x0A { discardingOversizedLine = false }
                continue
            }
            if byte == 0x0A {
                emitBufferedLine()
            } else if bytes.count < Self.maximumLineBytes {
                bytes.append(byte)
            } else {
                bytes.removeAll(keepingCapacity: true)
                discardingOversizedLine = true
            }
        }
    }

    func finish() {
        guard !discardingOversizedLine, !bytes.isEmpty else { return }
        emitBufferedLine()
    }

    private func emitBufferedLine() {
        if bytes.last == 0x0D { bytes.removeLast() }
        callbackGate.emit(String(decoding: bytes, as: UTF8.self))
        bytes.removeAll(keepingCapacity: true)
    }
}

final class ProcessOutputPipeReader {
    enum Outcome: Equatable {
        case pending
        case endOfFile
        case cancelled
        case failed(Int32)
    }

    private static let pollIntervalMilliseconds: Int32 = 20
    private static let chunkSize = 16 * 1024

    private let fileHandle: FileHandle
    private let onChunk: (Data) -> Void
    private let lock = NSLock()
    private var cancellationRequested = false
    private var storedOutcome = Outcome.pending

    init(fileHandle: FileHandle, onChunk: @escaping (Data) -> Void) {
        self.fileHandle = fileHandle
        self.onChunk = onChunk
    }

    var outcome: Outcome {
        lock.lock()
        defer { lock.unlock() }
        return storedOutcome
    }

    func cancel() {
        lock.lock()
        cancellationRequested = true
        lock.unlock()
    }

    func run() {
        let fileDescriptor = fileHandle.fileDescriptor
        var pollDescriptor = pollfd(
            fd: fileDescriptor,
            events: Int16(POLLIN | POLLHUP | POLLERR),
            revents: 0
        )
        var buffer = [UInt8](repeating: 0, count: Self.chunkSize)
        defer { try? fileHandle.close() }

        while true {
            if isCancellationRequested {
                finish(with: .cancelled)
                return
            }
            pollDescriptor.revents = 0
            let pollResult = Darwin.poll(
                &pollDescriptor,
                1,
                Self.pollIntervalMilliseconds
            )
            if pollResult == 0 { continue }
            if pollResult < 0 {
                let pollError = errno
                if pollError == EINTR { continue }
                finish(with: .failed(pollError))
                return
            }
            if pollDescriptor.revents & Int16(POLLNVAL) != 0 {
                finish(with: .failed(EBADF))
                return
            }
            guard pollDescriptor.revents & Int16(POLLIN | POLLHUP | POLLERR) != 0 else {
                continue
            }
            let byteCount = buffer.withUnsafeMutableBytes { storage in
                Darwin.read(fileDescriptor, storage.baseAddress, storage.count)
            }
            if byteCount > 0 {
                onChunk(Data(buffer.prefix(byteCount)))
                continue
            }
            if byteCount == 0 {
                finish(with: .endOfFile)
                return
            }
            let readError = errno
            if readError == EINTR || readError == EAGAIN || readError == EWOULDBLOCK {
                continue
            }
            finish(with: .failed(readError))
            return
        }
    }

    private var isCancellationRequested: Bool {
        lock.lock()
        defer { lock.unlock() }
        return cancellationRequested
    }

    private func finish(with outcome: Outcome) {
        lock.lock()
        storedOutcome = outcome
        lock.unlock()
    }
}

enum HubProcessExecutor {
    static let defaultMaximumOutputBytes = 256 * 1024
    static let defaultTimeout: TimeInterval = 5 * 60
    static let defaultTerminationGrace: TimeInterval = 2
    static let defaultOutputDrainTimeout: TimeInterval = 2

    static func run(executable: URL,
                    arguments: [String],
                    stdin: String? = nil,
                    environment: [String: String]? = nil,
                    maximumOutputBytes: Int = defaultMaximumOutputBytes,
                    timeout: TimeInterval = defaultTimeout,
                    terminationGrace: TimeInterval = defaultTerminationGrace,
                    outputDrainTimeout: TimeInterval = defaultOutputDrainTimeout,
                    onOutputLine: ((String) -> Void)? = nil,
                    completion: @escaping (Result<String, Error>) -> Void) {
        DispatchQueue.global(qos: .userInitiated).async {
            let process = Process()
            let output = Pipe()
            let retained = BoundedProcessOutput(maximumBytes: maximumOutputBytes)
            let callbackGate = ProcessOutputLineCallbackGate(callback: onOutputLine)
            let lineDecoder = ProcessOutputLineDecoder(callbackGate: callbackGate)
            let pipeReader = ProcessOutputPipeReader(
                fileHandle: output.fileHandleForReading
            ) { chunk in
                retained.append(chunk)
                lineDecoder.append(chunk)
            }
            let reader = DispatchGroup()
            let terminated = DispatchSemaphore(value: 0)
            process.executableURL = executable
            process.arguments = arguments
            if let environment {
                process.environment = ProcessInfo.processInfo.environment.merging(environment) { _, new in new }
            }
            process.standardOutput = output
            process.standardError = output
            if stdin != nil { process.standardInput = Pipe() }
            process.terminationHandler = { _ in terminated.signal() }
            do {
                try process.run()
                reader.enter()
                DispatchQueue.global(qos: .userInitiated).async {
                    pipeReader.run()
                    lineDecoder.finish()
                    reader.leave()
                }
                if let stdin, let input = process.standardInput as? Pipe {
                    input.fileHandleForWriting.write(Data(stdin.utf8))
                    input.fileHandleForWriting.closeFile()
                }
                if terminated.wait(timeout: .now() + max(0.001, timeout)) == .timedOut {
                    callbackGate.cancel()
                    let pid = process.processIdentifier
                    if process.isRunning { process.terminate() }
                    if terminated.wait(timeout: .now() + max(0.001, terminationGrace)) == .timedOut {
                        if process.isRunning { Darwin.kill(pid, SIGKILL) }
                        _ = terminated.wait(timeout: .now() + max(0.001, terminationGrace))
                    }
                    if reader.wait(timeout: .now() + max(0.001, outputDrainTimeout)) == .timedOut {
                        pipeReader.cancel()
                        _ = reader.wait(timeout: .now() + max(0.001, outputDrainTimeout))
                    }
                    completion(.failure(HubActionError.commandTimedOut))
                    return
                }
                guard reader.wait(timeout: .now() + max(0.001, outputDrainTimeout)) == .success else {
                    callbackGate.cancel()
                    pipeReader.cancel()
                    _ = reader.wait(timeout: .now() + max(0.001, outputDrainTimeout))
                    completion(.failure(HubActionError.commandFailed("Hub command output did not close.")))
                    return
                }
                callbackGate.cancel()
                guard pipeReader.outcome == .endOfFile else {
                    completion(.failure(HubActionError.commandFailed(
                        "Hub command output could not be read."
                    )))
                    return
                }
                let text = String(decoding: retained.snapshot(), as: UTF8.self)
                if process.terminationStatus == 0 {
                    completion(.success(text))
                } else {
                    completion(.failure(HubActionError.commandExited(
                        process.terminationStatus,
                        text.isEmpty ? "Hub command failed." : text
                    )))
                }
            } catch {
                callbackGate.cancel()
                try? output.fileHandleForReading.close()
                completion(.failure(error))
            }
        }
    }
}

final class EmbeddedHubCommandRunner: HubCommandRunning {
    func run(arguments: [String], completion: @escaping (Result<String, Error>) -> Void) {
        runProcess(arguments: arguments, stdin: nil, onOutputLine: nil, completion: completion)
    }

    func run(arguments: [String], stdin: String, completion: @escaping (Result<String, Error>) -> Void) {
        runProcess(arguments: arguments, stdin: stdin, onOutputLine: nil, completion: completion)
    }

    func run(arguments: [String],
             onOutputLine: @escaping (String) -> Void,
             completion: @escaping (Result<String, Error>) -> Void) {
        runProcess(arguments: arguments, stdin: nil, onOutputLine: onOutputLine, completion: completion)
    }

    private func runProcess(arguments: [String],
                            stdin: String?,
                            onOutputLine: ((String) -> Void)?,
                            completion: @escaping (Result<String, Error>) -> Void) {
        guard let executable = Bundle.main.url(forResource: "teslatlas-hub", withExtension: nil) else {
            completion(.failure(HubActionError.missingResource("teslatlas-hub")))
            return
        }
        HubProcessExecutor.run(executable: executable,
                               arguments: arguments,
                               stdin: stdin,
                               maximumOutputBytes: Self.maximumOutputBytes(for: arguments),
                               timeout: Self.timeout(for: arguments),
                               onOutputLine: onOutputLine,
                               completion: completion)
    }

    private static func timeout(for arguments: [String]) -> TimeInterval {
        if arguments.contains("migrate") { return 24 * 60 * 60 }
        if arguments.contains("doctor") { return 15 * 60 }
        if arguments.contains("teslamate-check") { return 5 * 60 }
        if arguments.contains("setup") { return 5 * 60 }
        if arguments.contains("status") || arguments.contains("preflight") { return 30 }
        return HubProcessExecutor.defaultTimeout
    }

    private static func maximumOutputBytes(for arguments: [String]) -> Int {
        if arguments.contains("doctor") { return 1024 * 1024 }
        return HubProcessExecutor.defaultMaximumOutputBytes
    }
}

final class InstalledHubCommandRunner: HubCommandRunning {
    private let executable = URL(fileURLWithPath: "/Library/Application Support/Teslatlas Hub/bin/teslatlas-hub")

    func run(arguments: [String], completion: @escaping (Result<String, Error>) -> Void) {
        runProcess(arguments: arguments, stdin: nil, onOutputLine: nil, completion: completion)
    }

    func run(arguments: [String], stdin: String, completion: @escaping (Result<String, Error>) -> Void) {
        runProcess(arguments: arguments, stdin: stdin, onOutputLine: nil, completion: completion)
    }

    func run(arguments: [String],
             onOutputLine: @escaping (String) -> Void,
             completion: @escaping (Result<String, Error>) -> Void) {
        runProcess(arguments: arguments, stdin: nil, onOutputLine: onOutputLine, completion: completion)
    }

    private func runProcess(arguments: [String],
                            stdin: String?,
                            onOutputLine: ((String) -> Void)?,
                            completion: @escaping (Result<String, Error>) -> Void) {
        let timeout: TimeInterval
        if arguments.contains("migrate") {
            timeout = 24 * 60 * 60
        } else if arguments.contains("doctor") {
            timeout = 15 * 60
        } else if arguments.contains("teslamate-check") || arguments.contains("setup") {
            timeout = 5 * 60
        } else if arguments.contains("control") {
            timeout = 45
        } else {
            timeout = 30
        }
        let maximumOutputBytes = arguments.contains("doctor")
            ? 1024 * 1024
            : HubProcessExecutor.defaultMaximumOutputBytes
        HubProcessExecutor.run(executable: executable,
                               arguments: arguments,
                               stdin: stdin,
                               maximumOutputBytes: maximumOutputBytes,
                               timeout: timeout,
                               onOutputLine: onOutputLine,
                               completion: completion)
    }
}

protocol HubInstalling {
    func install(completion: @escaping (Result<String, Error>) -> Void)
    func uninstall(deleteData: Bool, completion: @escaping (Result<String, Error>) -> Void)
}

final class EmbeddedInstaller: HubInstalling {
    func install(completion: @escaping (Result<String, Error>) -> Void) {
        guard let package = Bundle.main.url(forResource: "TeslatlasHubService", withExtension: "pkg") else {
            completion(.failure(HubActionError.missingResource("TeslatlasHubService.pkg")))
            return
        }
        guard let digest = Bundle.main.object(forInfoDictionaryKey: "TeslatlasServicePackageSHA256") as? String,
              let teamID = Bundle.main.object(forInfoDictionaryKey: "TeslatlasReleaseTeamIdentifier") as? String,
              Bundle.main.object(forInfoDictionaryKey: "TeslatlasOfficialRelease") as? Bool == true else {
            completion(.failure(HubActionError.untrustedInstaller(
                "signed release metadata is missing; local ad-hoc builds cannot install or update the service"
            )))
            return
        }
        do {
            let command = try Self.installCommand(packagePath: package.path,
                                                  appPath: Bundle.main.bundleURL.path,
                                                  expectedSHA256: digest,
                                                  expectedTeamID: teamID)
            runAdministratorCommand(command, completion: completion)
        } catch {
            completion(.failure(error))
        }
    }

    func uninstall(deleteData: Bool, completion: @escaping (Result<String, Error>) -> Void) {
        runAdministratorCommand(Self.uninstallCommand(deleteData: deleteData),
                                completion: completion)
    }

    static func installCommand(packagePath: String,
                               appPath: String,
                               expectedSHA256: String,
                               expectedTeamID: String) throws -> String {
        guard expectedSHA256.count == 64,
              expectedSHA256.unicodeScalars.allSatisfy({
                  (48 ... 57).contains($0.value) || (97 ... 102).contains($0.value)
              }) else {
            throw HubActionError.untrustedInstaller("package digest metadata is invalid")
        }
        guard expectedTeamID.count == 10,
              expectedTeamID.unicodeScalars.allSatisfy({
                  (48 ... 57).contains($0.value) || (65 ... 90).contains($0.value)
              }) else {
            throw HubActionError.untrustedInstaller("Team ID metadata is invalid")
        }
        return "staging=$(/usr/bin/mktemp -d /private/var/tmp/teslatlas-hub-install.XXXXXX)" +
            " || exit 1; " +
            "trap '/usr/bin/find -x \"$staging\" -depth -delete' EXIT HUP INT TERM; " +
            "app=\(shellQuote(appPath)); package=\(shellQuote(packagePath)); " +
            "expected_sha=\(shellQuote(expectedSHA256)); expected_team=\(shellQuote(expectedTeamID)); " +
            "staged=\"$staging/TeslatlasHubService.pkg\"; " +
            "/bin/test \"$(/usr/bin/stat -f '%u:%g:%Lp' \"$staging\")\" = 0:0:700" +
            " && /bin/test -d \"$app\" && /bin/test ! -L \"$app\"" +
            " && /bin/test \"$package\" = \"$app/Contents/Resources/TeslatlasHubService.pkg\"" +
            " && /bin/test -f \"$package\" && /bin/test ! -L \"$package\"" +
            " && /usr/bin/codesign --verify --deep --strict --verbose=2 \"$app\" >/dev/null 2>&1" +
            " && /usr/sbin/spctl --assess --type execute --verbose=4 \"$app\" >/dev/null 2>&1" +
            " && app_team=$(/usr/bin/codesign -dv --verbose=4 \"$app\" 2>&1" +
            " | /usr/bin/awk -F= '$1 == \"TeamIdentifier\" { print $2; exit }')" +
            " && /bin/test \"$app_team\" = \"$expected_team\"" +
            " && /bin/test \"$(/usr/libexec/PlistBuddy -c 'Print :TeslatlasServicePackageSHA256' \"$app/Contents/Info.plist\")\" = \"$expected_sha\"" +
            " && /bin/test \"$(/usr/libexec/PlistBuddy -c 'Print :TeslatlasReleaseTeamIdentifier' \"$app/Contents/Info.plist\")\" = \"$expected_team\"" +
            " && /bin/test \"$(/usr/libexec/PlistBuddy -c 'Print :TeslatlasOfficialRelease' \"$app/Contents/Info.plist\")\" = true" +
            " && /usr/bin/install -o root -g wheel -m 0600 \"$package\" \"$staged\"" +
            " && /bin/test -f \"$staged\" && /bin/test ! -L \"$staged\"" +
            " && /bin/test \"$(/usr/bin/stat -f '%u:%g:%Lp' \"$staged\")\" = 0:0:600" +
            " && actual_sha=$(/usr/bin/shasum -a 256 \"$staged\" | /usr/bin/awk '{ print $1 }')" +
            " && /bin/test \"$actual_sha\" = \"$expected_sha\"" +
            " && /usr/sbin/pkgutil --check-signature \"$staged\" >/dev/null 2>&1" +
            " && /usr/sbin/spctl --assess --type install \"$staged\" >/dev/null 2>&1" +
            " && package_team=$(/usr/sbin/spctl --assess --type install --verbose=4 \"$staged\" 2>&1" +
            " | /usr/bin/sed -nE 's/^origin=.*\\(([A-Z0-9]{10})\\)$/\\1/p')" +
            " && /bin/test \"$package_team\" = \"$expected_team\"" +
            " && /usr/sbin/installer -pkg \"$staged\" -target /"
    }

    static func uninstallCommand(deleteData: Bool) -> String {
        let option = deleteData ? " --delete-data" : ""
        let root = "/Library/Application Support/Teslatlas Hub"
        return "root=\(shellQuote(root)); libexec=\"$root/libexec\"; " +
            "uninstaller=\"$libexec/uninstall-macos-service.sh\"; common=\"$libexec/common.sh\"; " +
            "/bin/test -d \"$root\" && /bin/test ! -L \"$root\"" +
            " && /bin/test \"$(/usr/bin/stat -f '%u:%g' \"$root\")\" = 0:0" +
            " && /bin/test -z \"$(/usr/bin/find \"$root\" -prune -perm +022 -print)\"" +
            " && /bin/test -d \"$libexec\" && /bin/test ! -L \"$libexec\"" +
            " && /bin/test \"$(/usr/bin/stat -f '%u:%g' \"$libexec\")\" = 0:0" +
            " && /bin/test -z \"$(/usr/bin/find \"$libexec\" -prune -perm +022 -print)\"" +
            " && /bin/test -f \"$uninstaller\" && /bin/test ! -L \"$uninstaller\"" +
            " && /bin/test -x \"$uninstaller\"" +
            " && /bin/test -f \"$common\" && /bin/test ! -L \"$common\"" +
            " && /bin/test \"$(/usr/bin/stat -f '%u:%g' \"$uninstaller\")\" = 0:0" +
            " && /bin/test \"$(/usr/bin/stat -f '%u:%g' \"$common\")\" = 0:0" +
            " && /bin/test -z \"$(/usr/bin/find \"$uninstaller\" \"$common\" -prune -perm +022 -print)\"" +
            " && /bin/sh \"$uninstaller\"\(option)"
    }

    private func runAdministratorCommand(_ command: String,
                                         completion: @escaping (Result<String, Error>) -> Void) {
        let script = "do shell script \"\(Self.appleScriptQuote(command))\" with administrator privileges"
        HubProcessExecutor.run(executable: URL(fileURLWithPath: "/usr/bin/osascript"),
                               arguments: ["-e", script],
                               timeout: 15 * 60,
                               completion: completion)
    }

    private static func shellQuote(_ value: String) -> String { "'\(value.replacingOccurrences(of: "'", with: "'\\''"))'" }
    private static func appleScriptQuote(_ value: String) -> String { value.replacingOccurrences(of: "\\", with: "\\\\").replacingOccurrences(of: "\"", with: "\\\"") }
}

private enum ProcessRunner {
    static func run(executable: URL, arguments: [String], completion: @escaping (Result<String, Error>) -> Void) {
        HubProcessExecutor.run(executable: executable,
                               arguments: arguments,
                               timeout: 30,
                               completion: completion)
    }
}

enum HubServiceAction {
    case start
    case stop
    case restart
}

enum HubServiceLoadState {
    case loaded
    case unloaded
    case unknown(Error)
}

protocol HubServiceControlling: HubCommandRunning {
    func loadedState(completion: @escaping (HubServiceLoadState) -> Void)
}

final class LaunchctlServiceController: HubServiceControlling {
    func run(arguments: [String], completion: @escaping (Result<String, Error>) -> Void) {
        let action: HubServiceAction
        switch arguments.last {
        case "start": action = .start
        case "stop": action = .stop
        case "restart": action = .restart
        default:
            completion(.failure(HubActionError.commandFailed("Unknown service action.")))
            return
        }
        let domain = "gui/\(getuid())"
        let service = "\(domain)/com.teslatlas.hub"
        let plist = URL(fileURLWithPath: NSHomeDirectory()).appendingPathComponent("Library/LaunchAgents/com.teslatlas.hub.plist")
        loadedState { [weak self] loaded in
            switch loaded {
            case .loaded:
                self?.runCommands(Self.commandPlan(action: action, loaded: true, domain: domain, service: service, plist: plist.path), index: 0, completion: completion)
            case .unloaded:
                self?.runCommands(Self.commandPlan(action: action, loaded: false, domain: domain, service: service, plist: plist.path), index: 0, completion: completion)
            case let .unknown(error): completion(.failure(error))
            }
        }
    }

    func loadedState(completion: @escaping (HubServiceLoadState) -> Void) {
        let service = "gui/\(getuid())/com.teslatlas.hub"
        queryLoaded(service: service) { result in
            switch result {
            case .success(true): completion(.loaded)
            case .success(false): completion(.unloaded)
            case let .failure(error): completion(.unknown(error))
            }
        }
    }

    static func commandPlan(action: HubServiceAction, loaded: Bool, domain: String, service: String, plist: String) -> [[String]] {
        switch action {
        case .stop:
            return loaded ? [["bootout", service]] : []
        case .start:
            // RunAtLoad + KeepAlive starts an unloaded job during bootstrap.
            // Kicking it immediately kills that first process and launchd then
            // applies ThrottleInterval before starting it again.
            return loaded
                ? [["kickstart", service]]
                : [["bootstrap", domain, plist]]
        case .restart:
            return loaded
                ? [["bootout", service], ["bootstrap", domain, plist]]
                : [["bootstrap", domain, plist]]
        }
    }

    private func queryLoaded(service: String, completion: @escaping (Result<Bool, Error>) -> Void) {
        ProcessRunner.run(executable: URL(fileURLWithPath: "/bin/launchctl"), arguments: ["print", service]) { result in
            switch result {
            case .success: completion(.success(true))
            case let .failure(error):
                if case let HubActionError.commandExited(status, output) = error,
                   Self.isKnownUnloadedPrintFailure(status: status, output: output, service: service) {
                    completion(.success(false))
                } else {
                    completion(.failure(error))
                }
            }
        }
    }

    static func isKnownUnloadedPrintFailure(status: Int32, output: String, service: String) -> Bool {
        guard status == 113, let label = service.split(separator: "/").last else { return false }
        let expected = "Could not find service \"\(label)\" in domain for user gui: \(getuid())"
        return output.split(whereSeparator: \Character.isNewline).contains {
            $0.trimmingCharacters(in: .whitespacesAndNewlines) == expected
        }
    }

    private func runCommands(_ commands: [[String]], index: Int, completion: @escaping (Result<String, Error>) -> Void) {
        guard index < commands.count else { completion(.success("")); return }
        ProcessRunner.run(executable: URL(fileURLWithPath: "/bin/launchctl"), arguments: commands[index]) { [weak self] result in
            switch result {
            case .success:
                if commands[index].first == "bootout",
                   commands[index].count == 2 {
                    self?.waitUntilUnloaded(service: commands[index][1],
                                            attemptsRemaining: 100) { waitResult in
                        switch waitResult {
                        case .success:
                            self?.runCommands(commands, index: index + 1,
                                              completion: completion)
                        case let .failure(error): completion(.failure(error))
                        }
                    }
                } else {
                    self?.runCommands(commands, index: index + 1, completion: completion)
                }
            case let .failure(error): completion(.failure(error))
            }
        }
    }

    private func waitUntilUnloaded(service: String,
                                   attemptsRemaining: Int,
                                   completion: @escaping (Result<Void, Error>) -> Void) {
        queryLoaded(service: service) { [weak self] result in
            switch result {
            case .success(false): completion(.success(()))
            case .success(true) where attemptsRemaining > 1:
                DispatchQueue.global(qos: .userInitiated).asyncAfter(deadline: .now() + 0.1) {
                    self?.waitUntilUnloaded(service: service,
                                            attemptsRemaining: attemptsRemaining - 1,
                                            completion: completion)
                }
            case .success(true):
                completion(.failure(HubActionError.commandFailed(
                    "Hub service did not finish stopping."
                )))
            case let .failure(error): completion(.failure(error))
            }
        }
    }
}

final class HubController {
    static let previewOnboardingChecks = [
        HubOnboardingCheck(title: "Service", detail: "Launch agent installed and responsive", passed: true),
        HubOnboardingCheck(title: "Tesla account", detail: "Credentials stored and valid", passed: true),
        HubOnboardingCheck(title: "Vehicle", detail: "1 vehicle reachable", passed: true),
        HubOnboardingCheck(title: "Database", detail: "SQLite schema at revision 42", passed: true),
        HubOnboardingCheck(title: "Diagnostics", detail: "Preflight checks passed", passed: true),
        HubOnboardingCheck(title: "Logs", detail: "No errors in the last hour", passed: true)
    ]

    let previewMode: Bool
    let previewScene: HubPreviewScene?
    let onboardingPreviewRoute: String?
    private let commandRunner: HubCommandRunning
    private let installedCommandRunner: HubCommandRunning
    private let installer: HubInstalling
    private let serviceRunner: HubServiceControlling
    private let homeDirectory: URL
    private let serviceInstalledOverride: Bool?
    private let migrationStartupReadinessPollInterval: TimeInterval
    private let migrationStartupReadinessTimeout: TimeInterval
    private let migrationStartupReadinessMaxAttempts: Int
    private let migrationStartupReadinessNow: () -> Date
    private let migrationStartupReadinessSchedule: (
        _ delay: TimeInterval,
        _ action: @escaping () -> Void
    ) -> Void
    private(set) var snapshot: HubSnapshot
    private var lastStatusFailureCode: String?
    private let refreshRequestLock = NSLock()
    private var newestRefreshRequest: UInt64 = 0
    private let migrationHandoverStartLock = NSLock()
    private var migrationHandoverStartOperationID: UUID?

    init(environment: [String: String] = ProcessInfo.processInfo.environment,
         commandRunner: HubCommandRunning = EmbeddedHubCommandRunner(),
         installedCommandRunner: HubCommandRunning = InstalledHubCommandRunner(),
         installer: HubInstalling = EmbeddedInstaller(),
         serviceRunner: HubServiceControlling = LaunchctlServiceController(),
         homeDirectory: URL = URL(fileURLWithPath: NSHomeDirectory(), isDirectory: true),
         serviceInstalledOverride: Bool? = nil,
         initialSnapshot: HubSnapshot? = nil,
         migrationStartupReadinessPollInterval: TimeInterval = 0.5,
         migrationStartupReadinessTimeout: TimeInterval = 60,
         migrationStartupReadinessMaxAttempts: Int = 121,
         migrationStartupReadinessNow: @escaping () -> Date = Date.init,
         migrationStartupReadinessSchedule: @escaping (
             _ delay: TimeInterval,
             _ action: @escaping () -> Void
         ) -> Void = { delay, action in
             DispatchQueue.global(qos: .userInitiated).asyncAfter(
                 deadline: .now() + delay,
                 execute: action
             )
         }) {
        let scene = HubPreviewScene(environmentValue: environment["TESLATLAS_HUB_PREVIEW_SCENE"])
        let isPreview = environment["TESLATLAS_HUB_UI_PREVIEW"] == "1" || scene != nil
        let previewRoute = isPreview
            ? (scene?.onboardingRoute ?? environment["TESLATLAS_HUB_ONBOARDING_PREVIEW"])
            : nil
        previewMode = isPreview
        previewScene = scene
        onboardingPreviewRoute = previewRoute
        self.commandRunner = commandRunner
        self.installedCommandRunner = installedCommandRunner
        self.installer = installer
        self.serviceRunner = serviceRunner
        self.homeDirectory = homeDirectory
        self.serviceInstalledOverride = serviceInstalledOverride
        self.migrationStartupReadinessPollInterval = max(0, migrationStartupReadinessPollInterval)
        self.migrationStartupReadinessTimeout = max(0, migrationStartupReadinessTimeout)
        self.migrationStartupReadinessMaxAttempts = max(1, migrationStartupReadinessMaxAttempts)
        self.migrationStartupReadinessNow = migrationStartupReadinessNow
        self.migrationStartupReadinessSchedule = migrationStartupReadinessSchedule
        let firstRunPreviewRoutes = [
            "welcome", "choose", "choose-migration", "provider", "fleet", "legacy",
            "migration", "migration-connected", "verify", "finish", "finish-migration"
        ]
        let previewSnapshot: HubSnapshot = firstRunPreviewRoutes.contains(previewRoute ?? "")
            ? .firstRun : .previewRunning
        snapshot = initialSnapshot ?? (isPreview ? previewSnapshot : .firstRun)
    }

    static func isBundledServiceVersionOutput(_ output: String) -> Bool {
        output.trimmingCharacters(in: .whitespacesAndNewlines)
            == "teslatlas-hub \(HubRelease.bundledVersion)"
    }

    private func installedServiceMatchesBundledVersion(completion: @escaping (Bool) -> Void) {
        commandRunner.run(arguments: ["--version"]) { [weak self] bundledResult in
            guard let self,
                  case let .success(bundledOutput) = bundledResult,
                  Self.isBundledServiceVersionOutput(bundledOutput) else {
                completion(false)
                return
            }
            self.installedCommandRunner.run(arguments: ["--version"]) { installedResult in
                guard case let .success(installedOutput) = installedResult else {
                    completion(false)
                    return
                }
                completion(
                    installedOutput.trimmingCharacters(in: .whitespacesAndNewlines)
                        == bundledOutput.trimmingCharacters(in: .whitespacesAndNewlines)
                )
            }
        }
    }

    private func reuseOrUpdateInstalledService(
        completion: @escaping (Result<String, Error>) -> Void
    ) {
        installedServiceMatchesBundledVersion { matches in
            if matches {
                HubAppLog.shared.record("installed_version.reused", category: "service")
                completion(.success("Matching service already installed"))
            } else {
                self.installer.install(completion: completion)
            }
        }
    }

    var hasPendingMigrationHandover: Bool {
        !previewMode && FileManager.default.fileExists(atPath: migrationHandoverMarker.path)
    }

    var pendingMigrationHandoverPhase: HubMigrationHandoverPhase? {
        previewMode ? nil : migrationHandoverState?.phase
    }

    func shouldShowOnboarding(for snapshot: HubSnapshot) -> Bool {
        onboardingPreviewRoute != nil
            || hasPendingMigrationHandover
            || !FileManager.default.fileExists(atPath: configPath.path)
            || snapshot.health == .needsInstall
            || snapshot.account == "Not configured"
    }

    func refresh(completion: @escaping (HubSnapshot) -> Void) {
        guard !previewMode else {
            completion(snapshot)
            return
        }
        let request = beginRefreshRequest()
        serviceRunner.loadedState { [weak self] loaded in
            guard let self else { return }
            let installed = self.isServiceInstalled
            let runner = installed ? self.installedCommandRunner : self.commandRunner
            runner.run(arguments: ["--config", self.configPath.path, "status"]) { result in
                DispatchQueue.main.async {
                    guard self.isNewestRefreshRequest(request) else {
                        completion(self.snapshot)
                        return
                    }
                    switch result {
                    case let .success(output):
                        if let status = self.parseStatus(output) {
                            if let previousCode = self.lastStatusFailureCode {
                                HubAppLog.shared.record("status.recovered", category: "dashboard",
                                                        fields: ["previous_error_code": previousCode])
                            }
                            self.lastStatusFailureCode = nil
                            self.snapshot = self.statusSnapshot(status, installed: installed,
                                                                loaded: loaded)
                        } else {
                            self.recordStatusFailure("invalid_status_output", installed: installed)
                            self.snapshot = self.fallbackSnapshot(installed: installed, loaded: loaded)
                        }
                    case let .failure(error):
                        self.recordStatusFailure(HubAppLog.errorCode(error), installed: installed)
                        self.snapshot = self.fallbackSnapshot(installed: installed, loaded: loaded)
                    }
                    completion(self.snapshot)
                }
            }
        }
    }

    private func beginRefreshRequest() -> UInt64 {
        refreshRequestLock.lock()
        defer { refreshRequestLock.unlock() }
        newestRefreshRequest &+= 1
        return newestRefreshRequest
    }

    private func isNewestRefreshRequest(_ request: UInt64) -> Bool {
        refreshRequestLock.lock()
        defer { refreshRequestLock.unlock() }
        return request == newestRefreshRequest
    }

    private func recordStatusFailure(_ code: String, installed: Bool) {
        guard lastStatusFailureCode != code else { return }
        lastStatusFailureCode = code
        HubAppLog.shared.record("status.failed", category: "dashboard", level: "WARN",
                                fields: [
                                    "error_code": code,
                                    "service_installed": installed ? "true" : "false"
                                ])
    }

    func installService(completion: @escaping (Result<Void, Error>) -> Void) {
        guard !previewMode else { completion(.failure(HubActionError.preview)); return }
        let started = Date()
        HubAppLog.shared.record("install.requested", category: "service")
        let finish: (Result<String, Error>) -> Void = { [weak self] result in
            DispatchQueue.main.async {
                switch result {
                case .success:
                    HubAppLog.shared.record("install.completed", category: "service", fields: [
                        "duration_ms": String(Int(Date().timeIntervalSince(started) * 1000))
                    ])
                    self?.refresh { _ in completion(.success(())) }
                case let .failure(error):
                    HubAppLog.shared.record("install.failed", category: "service", level: "ERROR",
                                            fields: [
                                                "duration_ms": String(Int(Date().timeIntervalSince(started) * 1000)),
                                                "error_code": HubAppLog.errorCode(error)
                                            ])
                    completion(.failure(error))
                }
            }
        }
        installer.install(completion: finish)
    }

    func uninstallService(deleteData: Bool, completion: @escaping (Result<Void, Error>) -> Void) {
        guard !previewMode else { completion(.failure(HubActionError.preview)); return }
        let started = Date()
        HubAppLog.shared.record("uninstall.requested", category: "service", fields: [
            "delete_data": deleteData ? "true" : "false"
        ])
        installer.uninstall(deleteData: deleteData) { result in
            DispatchQueue.main.async {
                switch result {
                case .success:
                    HubAppLog.shared.record("uninstall.completed", category: "service", fields: [
                        "delete_data": deleteData ? "true" : "false",
                        "duration_ms": String(Int(Date().timeIntervalSince(started) * 1000))
                    ])
                    self.refresh { _ in completion(.success(())) }
                case let .failure(error):
                    HubAppLog.shared.record("uninstall.failed", category: "service", level: "ERROR",
                                            fields: [
                                                "delete_data": deleteData ? "true" : "false",
                                                "duration_ms": String(Int(Date().timeIntervalSince(started) * 1000)),
                                                "error_code": HubAppLog.errorCode(error)
                                            ])
                    completion(.failure(error))
                }
            }
        }
    }

    func signOutTeslaAccount(completion: @escaping (Result<Void, Error>) -> Void) {
        guard !previewMode else { completion(.failure(HubActionError.preview)); return }
        guard !hasPendingMigrationHandover else {
            completion(.failure(HubActionError.commandFailed(
                "Finish or cancel the TeslaMate migration handover before signing out."
            )))
            return
        }
        HubAppLog.shared.record("sign_out.requested", category: "account")
        let runner = isServiceInstalled ? installedCommandRunner : commandRunner
        runner.run(arguments: ["--config", configPath.path, "control", "sign-out"]) { [weak self] result in
            DispatchQueue.main.async {
                guard let self else { completion(result.map { _ in () }); return }
                switch result {
                case .success:
                    HubAppLog.shared.record("sign_out.completed", category: "account")
                    self.refresh { _ in completion(.success(())) }
                case let .failure(error):
                    HubAppLog.shared.record("sign_out.failed", category: "account", level: "ERROR",
                                            fields: ["error_code": HubAppLog.errorCode(error)])
                    self.refresh { _ in
                        completion(.failure(HubActionError.commandFailed(
                            "Disconnect did not finish cleanly. Hub status was refreshed; check whether the account is still connected. \(error.localizedDescription)"
                        )))
                    }
                }
            }
        }
    }

    func checkTeslaMateCompatibility(source: String,
                                     carID: String,
                                     passwordFile: String,
                                     acknowledgeV42CompatibleSchema: Bool,
                                     completion: @escaping (Result<HubTeslaMateCompatibility, Error>) -> Void) {
        guard !previewMode else { completion(.failure(HubActionError.preview)); return }
        guard acknowledgeV42CompatibleSchema else {
            completion(.failure(HubActionError.commandFailed(
                "Confirm TeslaMate 4.2.0 or newer before checking compatibility."
            )))
            return
        }
        do {
            try Self.validateMigrationSource(source)
            guard let selectedCarID = Int64(carID), selectedCarID > 0 else {
                throw HubActionError.commandFailed("TeslaMate car ID must be a positive number.")
            }
            guard !passwordFile.isEmpty else {
                throw HubActionError.commandFailed("Choose the protected PostgreSQL password file.")
            }
            let arguments = ["--config", configPath.path, "teslamate-check",
                             "--source", source, "--car-id", String(selectedCarID),
                             "--postgres-password-file", passwordFile,
                             "--acknowledge-v4-2-compatible-schema"]
            commandRunner.run(arguments: arguments) { result in
                DispatchQueue.main.async {
                    switch result {
                    case let .success(output):
                        guard let report = Self.parseTeslaMateCompatibility(output) else {
                            completion(.failure(HubActionError.commandFailed(
                                "TeslaMate compatibility check returned no valid report."
                            )))
                            return
                        }
                        completion(.success(report))
                    case let .failure(error):
                        if let report = Self.parseTeslaMateCompatibility(error.localizedDescription) {
                            completion(.success(report))
                        } else {
                            completion(.failure(HubActionError.commandFailed(
                                "Could not verify TeslaMate. Check the server connection and try again."
                            )))
                        }
                    }
                }
            }
        } catch {
            completion(.failure(error))
        }
    }

    func importTeslaMateOnline(source: String,
                               carID: String,
                               passwordFile: String,
                               encryptionKeyFile: String,
                               acknowledgeV42CompatibleSchema: Bool,
                               progress: @escaping (HubMigrationProgress) -> Void = { _ in },
                               completion: @escaping (Result<Void, Error>) -> Void) {
        HubAppLog.shared.record("import.requested", category: "teslamate_import",
                                fields: ["capture_mode": "online_snapshot"])
        guard !previewMode else { completion(.failure(HubActionError.preview)); return }
        guard acknowledgeV42CompatibleSchema else {
            completion(.failure(HubActionError.commandFailed(
                "Confirm TeslaMate 4.2.0 or newer before importing."
            )))
            return
        }
        guard !encryptionKeyFile.isEmpty else {
            completion(.failure(HubActionError.commandFailed(
                "Choose the TeslaMate ENCRYPTION_KEY file."
            )))
            return
        }
        checkTeslaMateCompatibility(source: source,
                                    carID: carID,
                                    passwordFile: passwordFile,
                                    acknowledgeV42CompatibleSchema: acknowledgeV42CompatibleSchema) { [weak self] checkResult in
            guard let self else { return }
            switch checkResult {
            case let .failure(error):
                HubAppLog.shared.record("import.preflight.failed", category: "teslamate_import",
                                        level: "ERROR",
                                        fields: ["error_code": HubAppLog.errorCode(error)])
                completion(.failure(error))
            case let .success(report):
                guard report.compatible else {
                    HubAppLog.shared.record("import.preflight.rejected", category: "teslamate_import",
                                            level: "WARN", fields: ["reason": report.reasonCode])
                    completion(.failure(HubActionError.commandFailed(report.message)))
                    return
                }
                HubAppLog.shared.record("import.preflight.completed", category: "teslamate_import")
                self.prepareOnlineMigration(source: source,
                                            carID: carID,
                                            passwordFile: passwordFile,
                                            encryptionKeyFile: encryptionKeyFile,
                                            progress: progress,
                                            completion: completion)
            }
        }
    }

    private func prepareOnlineMigration(source: String,
                                        carID: String,
                                        passwordFile: String,
                                        encryptionKeyFile: String,
                                        progress: @escaping (HubMigrationProgress) -> Void,
                                        completion: @escaping (Result<Void, Error>) -> Void) {
        let previousInterval = migrationHandoverState?.previousIntervalSeconds
            ?? configuredCollectorIntervalSeconds()
        let previousProvider = migrationHandoverState?.previousProvider
            ?? configuredCollectorProvider()
        let originalConfig: String?
        do {
            originalConfig = try readConfigIfPresent()
        } catch {
            completion(.failure(error))
            return
        }
        do {
            try writeMigrationHandoverMarker(
                HubMigrationHandoverState(phase: .importing,
                                          previousIntervalSeconds: previousInterval,
                                          previousProvider: previousProvider)
            )
            try ensureConfig(collectorIntervalSeconds: 0)
        } catch {
            completion(.failure(recoverFailedImport(error, originalConfig: originalConfig)))
            return
        }
        let arguments = ["--config", configPath.path, "migrate",
                         "--source", source, "--car-id", carID,
                         "--postgres-password-file", passwordFile,
                         "--encryption-key-file", encryptionKeyFile,
                         "--online-snapshot",
                         "--preserve-existing-credentials",
                         "--acknowledge-v4-2-compatible-schema"]
        let finish: (Result<Void, Error>) -> Void = { result in
            DispatchQueue.main.async { completion(result) }
        }
        let abortBeforeImport: (Error) -> Void = { [weak self] error in
            guard let self else { finish(.failure(error)); return }
            finish(.failure(self.recoverFailedImport(error, originalConfig: originalConfig)))
        }
        let failStartedImport: (Error) -> Void = { error in
            finish(.failure(Self.migrationStoppedError(error)))
        }
        let runImport = { [weak self] in
            guard let self else { return }
            let diagnostics = HubMigrationProgressDiagnostics()
            let progressDelivery = HubMigrationProgressDelivery()
            HubAppLog.shared.record("import.process.started", category: "teslamate_import",
                                    fields: ["capture_mode": "online_snapshot"])
            self.commandRunner.run(arguments: arguments, onOutputLine: { line in
                guard let update = Self.parseMigrationProgress(line) else { return }
                diagnostics.received(update)
                progressDelivery.deliver(update, to: progress)
            }) { result in
                progressDelivery.cancel()
                let durationFields = diagnostics.finish()
                switch result {
                case let .success(output):
                    guard Self.containsOnlineMigrationReport(output) else {
                        HubAppLog.shared.record("import.process.invalid_report",
                                                category: "teslamate_import", level: "ERROR",
                                                fields: durationFields)
                        failStartedImport(HubActionError.commandFailed(
                            "TeslaMate import returned no valid completion report. Hub remains stopped."
                        ))
                        return
                    }
                    do {
                        try self.writeMigrationHandoverMarker(
                            HubMigrationHandoverState(phase: .awaitingVerification,
                                                      previousIntervalSeconds: previousInterval,
                                                      previousProvider: previousProvider)
                        )
                        HubAppLog.shared.record("import.completed", category: "teslamate_import",
                                                fields: durationFields.merging(
                                                    ["handover": "awaiting_verification"]
                                                ) { _, new in new })
                        finish(.success(()))
                    } catch {
                        HubAppLog.shared.record("import.handover.failed", category: "teslamate_import",
                                                level: "ERROR",
                                                fields: durationFields.merging(
                                                    ["error_code": HubAppLog.errorCode(error)]
                                                ) { _, new in new })
                        finish(.failure(HubActionError.commandFailed(
                            "Import completed, but Hub could not record the safe handover gate: \(error.localizedDescription). Hub remains stopped."
                        )))
                    }
                case let .failure(error):
                    HubAppLog.shared.record("import.process.failed", category: "teslamate_import",
                                            level: "ERROR",
                                            fields: durationFields.merging(
                                                [
                                                    "error_code": HubAppLog.errorCode(error),
                                                    "reason_code": Self.migrationFailureReasonCode(error)
                                                ]
                                            ) { _, new in new })
                    failStartedImport(error)
                }
            }
        }
        // This controls Teslatlas Hub only. TeslaMate is never stopped or changed.
        guard isServiceInstalled else {
            runImport()
            return
        }
        serviceRunner.run(arguments: ["service", "stop"]) { stopResult in
            switch stopResult {
            case .success:
                HubAppLog.shared.record("local_hub.stopped", category: "teslamate_import")
                runImport()
            case let .failure(error):
                HubAppLog.shared.record("local_hub.stop_failed", category: "teslamate_import",
                                        level: "ERROR",
                                        fields: ["error_code": HubAppLog.errorCode(error)])
                abortBeforeImport(error)
            }
        }
    }

    static func parseTeslaMateCompatibility(_ output: String) -> HubTeslaMateCompatibility? {
        for line in output.split(whereSeparator: { $0.isNewline }) {
            guard let data = String(line).data(using: .utf8),
                  let root = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
                  let status = root["status"] as? String,
                  let reason = root["reasonCode"] as? String,
                  let required = root["requiredVersion"] as? String,
                  let guidance = root["guidance"] as? String else { continue }
            return HubTeslaMateCompatibility(
                compatible: status == "compatible"
                    && reason == "v4_2_compatible_schema"
                    && required == "4.2.0",
                message: guidance,
                reasonCode: reason,
                requiredVersion: required
            )
        }
        return nil
    }

    static func parseMigrationProgress(_ line: String) -> HubMigrationProgress? {
        guard let data = line.data(using: .utf8),
              let payload = try? JSONDecoder().decode(HubMigrationProgressPayload.self, from: data),
              payload.event == "migration_progress",
              payload.totalRows > 0 else { return nil }
        let safePhase = payload.phase.flatMap { phase in
            phase.range(of: #"^[a-z0-9_-]{1,64}$"#, options: .regularExpression) == nil
                ? nil
                : phase
        }
        return HubMigrationProgress(completedRows: min(payload.completedRows, payload.totalRows),
                                    totalRows: payload.totalRows,
                                    phase: safePhase)
    }

    static func containsOnlineMigrationReport(_ output: String) -> Bool {
        output.split(whereSeparator: { $0.isNewline }).contains { line in
            guard let data = String(line).data(using: .utf8),
                  let root = try? JSONSerialization.jsonObject(with: data) as? [String: Any] else {
                return false
            }
            return root["status"] as? String == "imported"
                && root["captureMode"] as? String == "online-snapshot"
        }
    }

    func importTeslaMate(source: String,
                         carID: String,
                         passwordFile: String,
                         encryptionKeyFile: String,
                         acknowledgeV42CompatibleSchema: Bool,
                         completion: @escaping (Result<Void, Error>) -> Void) {
        guard !previewMode else { completion(.failure(HubActionError.preview)); return }
        guard acknowledgeV42CompatibleSchema else {
            completion(.failure(HubActionError.commandFailed(
                "Confirm TeslaMate 4.2.0 or newer before importing from a direct PostgreSQL source."
            )))
            return
        }
        importTeslaMateOnline(source: source,
                              carID: carID,
                              passwordFile: passwordFile,
                              encryptionKeyFile: encryptionKeyFile,
                              acknowledgeV42CompatibleSchema: acknowledgeV42CompatibleSchema,
                              completion: completion)
    }

    static func validateMigrationSource(_ source: String) throws {
        guard let components = URLComponents(string: source),
              let scheme = components.scheme?.lowercased(),
              scheme == "postgres" || scheme == "postgresql",
              let host = components.host, !host.isEmpty,
              components.path.count > 1 else {
            throw HubActionError.commandFailed(
                "PostgreSQL source must include a postgres or postgresql scheme, host, and database name."
            )
        }
        guard components.password == nil else {
            throw HubActionError.commandFailed("PostgreSQL source must not contain a password. Use the password file field.")
        }
    }

    func configureFleetAccount(credentials: HubFleetSetupCredentials,
                               completion: @escaping (Result<Void, Error>) -> Void) {
        guard !previewMode else { completion(.failure(HubActionError.preview)); return }
        let installed = isServiceInstalled
        let setupStarted = Date()
        HubAppLog.shared.record("setup.requested", category: "account", fields: [
            "provider": "fleet",
            "service_installed": installed ? "true" : "false"
        ])
        let invocation: HubSetupInvocation
        let originalConfig: String?
        do {
            invocation = try Self.fleetSetupInvocation(configPath: configPath,
                                                       credentials: credentials)
            originalConfig = try readConfigIfPresent()
        } catch {
            HubAppLog.shared.record("setup.rejected", category: "account", level: "WARN",
                                    fields: [
                                        "provider": "fleet",
                                        "error_code": HubAppLog.errorCode(error)
                                    ])
            completion(.failure(error))
            return
        }
        let finish: (Result<Void, Error>) -> Void = { [weak self] result in
            DispatchQueue.main.async {
                guard let self else { completion(result); return }
                switch result {
                case .success:
                    HubAppLog.shared.record("setup.completed", category: "account", fields: [
                        "provider": "fleet",
                        "duration_ms": String(Int(Date().timeIntervalSince(setupStarted) * 1000))
                    ])
                    self.refresh { _ in completion(.success(())) }
                case let .failure(error):
                    HubAppLog.shared.record("setup.failed", category: "account", level: "ERROR",
                                            fields: [
                                                "provider": "fleet",
                                                "duration_ms": String(Int(Date().timeIntervalSince(setupStarted) * 1000)),
                                                "error_code": HubAppLog.errorCode(error)
                                            ])
                    completion(result)
                }
            }
        }
        let startService = { [weak self] in
            guard let self else { return }
            self.serviceRunner.run(arguments: ["service", "start"]) { result in
                switch result {
                case .success: finish(.success(()))
                case let .failure(error): finish(.failure(error))
                }
            }
        }
        guard installed else {
            do {
                try ensureConfig(provider: "fleet")
            } catch {
                finish(.failure(error))
                return
            }
            commandRunner.run(arguments: invocation.arguments,
                              stdin: invocation.standardInput) { [weak self] result in
                guard let self else { return }
                switch result {
                case .success:
                    self.installer.install { installResult in
                        switch installResult {
                        case .success:
                            self.serviceRunner.loadedState { state in
                                switch state {
                                case .loaded: finish(.success(()))
                                case .unloaded: startService()
                                case let .unknown(error): finish(.failure(error))
                                }
                            }
                        case let .failure(error): finish(.failure(error))
                        }
                    }
                case let .failure(error): finish(.failure(error))
                }
            }
            return
        }

        if snapshot.account != "Connected" {
            let restoreBeforeMutation = { [weak self] (setupError: Error) in
                guard let self else { return }
                do {
                    try self.restoreConfig(originalConfig)
                    finish(.failure(setupError))
                } catch let recoveryError {
                    finish(.failure(HubActionError.commandFailed(
                        "Fleet setup failed: \(setupError.localizedDescription) Hub configuration recovery also failed: \(recoveryError.localizedDescription)"
                    )))
                }
            }
            serviceRunner.run(arguments: ["service", "stop"]) { [weak self] stopResult in
                guard let self else { return }
                guard case .success = stopResult else {
                    if case let .failure(error) = stopResult { finish(.failure(error)) }
                    return
                }
                do {
                    try self.ensureConfig(provider: "fleet")
                } catch {
                    restoreBeforeMutation(error)
                    return
                }
                // No working old provider exists. Configure with the embedded
                // current binary, then package that same version. Never restart
                // the old binary after this point because setup may migrate data.
                self.commandRunner.run(arguments: invocation.arguments,
                                       stdin: invocation.standardInput) { setupResult in
                    switch setupResult {
                    case .success:
                        self.installedServiceMatchesBundledVersion { matches in
                            if matches {
                                HubAppLog.shared.record("installed_version.reused",
                                                        category: "service",
                                                        fields: ["provider": "fleet"])
                                startService()
                                return
                            }
                            self.installer.install { installResult in
                                switch installResult {
                                case .success: startService()
                                case let .failure(error):
                                    finish(.failure(HubActionError.commandFailed(
                                        "Fleet is configured, but the service update failed. Hub remains stopped; retry Update Service. \(error.localizedDescription)"
                                    )))
                                }
                            }
                        }
                    case let .failure(error):
                        finish(.failure(Self.providerSwitchStoppedError(error)))
                    }
                }
            }
            return
        }

        serviceRunner.loadedState { [weak self] state in
            guard let self else { return }
            let wasLoaded: Bool
            switch state {
            case .loaded: wasLoaded = true
            case .unloaded: wasLoaded = false
            case let .unknown(error):
                finish(.failure(error))
                return
            }
            let recover = { (setupError: Error, restartIsSafe: Bool) in
                guard restartIsSafe else {
                    finish(.failure(Self.providerSwitchStoppedError(setupError)))
                    return
                }
                guard let originalConfig else {
                    finish(.failure(setupError))
                    return
                }
                do {
                    try self.restoreConfig(originalConfig)
                } catch let recoveryError {
                    finish(.failure(HubActionError.commandFailed(
                        "Fleet setup failed: \(setupError.localizedDescription) Hub configuration recovery also failed: \(recoveryError.localizedDescription)"
                    )))
                    return
                }
                guard wasLoaded else {
                    finish(.failure(setupError))
                    return
                }
                self.serviceRunner.run(arguments: ["service", "start"]) { restartResult in
                    switch restartResult {
                    case .success: finish(.failure(setupError))
                    case let .failure(startError):
                        finish(.failure(HubActionError.commandFailed(
                            "Fleet setup failed: \(setupError.localizedDescription) Hub restart also failed: \(startError.localizedDescription)"
                        )))
                    }
                }
            }
            self.serviceRunner.run(arguments: ["service", "stop"]) { stopResult in
                guard case .success = stopResult else {
                    if case let .failure(error) = stopResult { finish(.failure(error)) }
                    return
                }
                // Reuse the matching package; only upgrade when versions differ.
                // Keep the existing provider config through any package preflight.
                self.reuseOrUpdateInstalledService { installResult in
                    switch installResult {
                    case .success:
                        do {
                            try self.ensureConfig(provider: "fleet")
                        } catch {
                            recover(error, true)
                            return
                        }
                        self.installedCommandRunner.run(arguments: invocation.arguments,
                                                        stdin: invocation.standardInput) { setupResult in
                            switch setupResult {
                            case .success: startService()
                            case let .failure(error):
                                recover(error, false)
                            }
                        }
                    case let .failure(error):
                        recover(error, !Self.isForwardOnlyUpgradeFailure(error))
                    }
                }
            }
        }
    }

    static func fleetSetupInvocation(configPath: URL,
                                     credentials: HubFleetSetupCredentials) throws -> HubSetupInvocation {
        guard !credentials.accessToken.isEmpty,
              !credentials.refreshToken.isEmpty,
              !credentials.clientID.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty,
              ["europe_middle_east_and_africa", "north_america_and_asia_pacific", "china"]
                .contains(credentials.region),
              credentials.expiresInSeconds > 0 else {
            throw HubActionError.commandFailed("Fleet credentials are incomplete or invalid.")
        }
        let payload: [String: Any] = [
            "accessToken": credentials.accessToken,
            "refreshToken": credentials.refreshToken,
            "clientId": credentials.clientID,
            "region": credentials.region,
            "expiresInSeconds": credentials.expiresInSeconds
        ]
        let data = try JSONSerialization.data(withJSONObject: payload, options: [])
        guard let input = String(data: data, encoding: .utf8) else {
            throw HubActionError.commandFailed("Could not encode Fleet credentials.")
        }
        return HubSetupInvocation(
            arguments: ["--config", configPath.path, "setup-fleet", "--all-vehicles"],
            standardInput: input
        )
    }

    func configureTeslaAccount(tokens: TeslaAuthTokens,
                               vehicleID: Int64? = nil,
                               completion: @escaping (Result<Void, Error>) -> Void) {
        guard !previewMode else { completion(.failure(HubActionError.preview)); return }
        let installed = isServiceInstalled
        let setupStarted = Date()
        HubAppLog.shared.record("setup.requested", category: "account", fields: [
            "provider": "legacy",
            "service_installed": installed ? "true" : "false"
        ])
        let invocation: HubSetupInvocation
        let installedInvocation: HubSetupInvocation
        let originalConfig: String?
        do {
            invocation = try Self.setupInvocation(configPath: configPath,
                                                  tokens: tokens,
                                                  vehicleID: vehicleID)
            installedInvocation = Self.oldCompatibleSetupInvocation(invocation)
            originalConfig = installed ? try readConfigIfPresent() : nil
        } catch {
            HubAppLog.shared.record("setup.rejected", category: "account", level: "WARN",
                                    fields: [
                                        "provider": "legacy",
                                        "error_code": HubAppLog.errorCode(error)
                                    ])
            completion(.failure(error))
            return
        }
        let finish: (Result<Void, Error>) -> Void = { [weak self] result in
            DispatchQueue.main.async {
                guard let self else { completion(result); return }
                switch result {
                case .success:
                    HubAppLog.shared.record("setup.completed", category: "account", fields: [
                        "provider": "legacy",
                        "duration_ms": String(Int(Date().timeIntervalSince(setupStarted) * 1000))
                    ])
                    self.refresh { _ in completion(.success(())) }
                case let .failure(error):
                    HubAppLog.shared.record("setup.failed", category: "account", level: "ERROR",
                                            fields: [
                                                "provider": "legacy",
                                                "duration_ms": String(Int(Date().timeIntervalSince(setupStarted) * 1000)),
                                                "error_code": HubAppLog.errorCode(error)
                                            ])
                    completion(result)
                }
            }
        }
        let startService = { [weak self] in
            guard let self else { return }
            self.serviceRunner.run(arguments: ["service", "start"]) { result in
                finish(result.map { _ in () })
            }
        }
        guard installed else {
            do {
                try ensureConfig(provider: "legacy")
            } catch {
                finish(.failure(error))
                return
            }
            commandRunner.run(arguments: invocation.arguments,
                              stdin: invocation.standardInput) { [weak self] setupResult in
                guard let self else { return }
                switch setupResult {
                case .success:
                    self.installer.install { installResult in
                        finish(installResult.map { _ in () })
                    }
                case let .failure(error):
                    finish(.failure(error))
                }
            }
            return
        }

        if snapshot.account != "Connected" {
            let restoreBeforeMutation = { [weak self] (setupError: Error) in
                guard let self else { return }
                do {
                    try self.restoreConfig(originalConfig)
                    finish(.failure(setupError))
                } catch let recoveryError {
                    finish(.failure(HubActionError.commandFailed(
                        "Tesla setup failed: \(setupError.localizedDescription) Hub configuration recovery also failed: \(recoveryError.localizedDescription)"
                    )))
                }
            }
            serviceRunner.run(arguments: ["service", "stop"]) { [weak self] stopResult in
                guard let self else { return }
                guard case .success = stopResult else {
                    if case let .failure(error) = stopResult { finish(.failure(error)) }
                    return
                }
                do {
                    try self.ensureConfig(provider: "legacy")
                } catch {
                    restoreBeforeMutation(error)
                    return
                }
                // An installed but unconfigured package cannot pass package
                // preflight. Configure with the embedded current binary first,
                // then install that exact version and start it.
                self.commandRunner.run(arguments: invocation.arguments,
                                       stdin: invocation.standardInput) { setupResult in
                    switch setupResult {
                    case .success:
                        self.installedServiceMatchesBundledVersion { matches in
                            if matches {
                                HubAppLog.shared.record("installed_version.reused",
                                                        category: "service",
                                                        fields: ["provider": "legacy"])
                                startService()
                                return
                            }
                            self.installer.install { installResult in
                                switch installResult {
                                case .success: startService()
                                case let .failure(error):
                                    finish(.failure(HubActionError.commandFailed(
                                        "Legacy Tesla login is configured, but the service update failed. Hub remains stopped; retry Update Service. \(error.localizedDescription)"
                                    )))
                                }
                            }
                        }
                    case let .failure(error):
                        finish(.failure(Self.providerSwitchStoppedError(error)))
                    }
                }
            }
            return
        }

        serviceRunner.loadedState { [weak self] state in
            guard let self else { return }
            let wasLoaded: Bool
            switch state {
            case .loaded: wasLoaded = true
            case .unloaded: wasLoaded = false
            case let .unknown(error):
                finish(.failure(error))
                return
            }
            let recover = { (action: String, actionError: Error, restartIsSafe: Bool) in
                guard restartIsSafe else {
                    finish(.failure(Self.providerSwitchStoppedError(actionError)))
                    return
                }
                do {
                    try self.restoreConfig(originalConfig)
                } catch let recoveryError {
                    finish(.failure(HubActionError.commandFailed(
                        "\(action): \(actionError.localizedDescription) Hub configuration recovery also failed: \(recoveryError.localizedDescription)"
                    )))
                    return
                }
                guard wasLoaded else {
                    finish(.failure(actionError))
                    return
                }
                self.serviceRunner.run(arguments: ["service", "start"]) { restartResult in
                    switch restartResult {
                    case .success:
                        finish(.failure(actionError))
                    case let .failure(restartError):
                        finish(.failure(HubActionError.commandFailed(
                            "\(action): \(actionError.localizedDescription) Hub restart also failed: \(restartError.localizedDescription)"
                        )))
                    }
                }
            }
            let handleSetupResult: (Result<String, Error>) -> Void = { setupResult in
                switch setupResult {
                case .success:
                    startService()
                case let .failure(error):
                    recover("Tesla setup failed", error, false)
                }
            }
            let runSetup = {
                self.installedCommandRunner.run(arguments: invocation.arguments,
                                                stdin: invocation.standardInput) { setupResult in
                    if case let .failure(error) = setupResult,
                       Self.isAllVehiclesUnsupported(error) {
                        self.installedCommandRunner.run(arguments: installedInvocation.arguments,
                                                        stdin: installedInvocation.standardInput,
                                                        completion: handleSetupResult)
                    } else {
                        handleSetupResult(setupResult)
                    }
                }
            }
            self.serviceRunner.run(arguments: ["service", "stop"]) { stopResult in
                guard case .success = stopResult else {
                    if case let .failure(error) = stopResult { finish(.failure(error)) }
                    return
                }
                // Preserve the old provider through any required package upgrade.
                // A matching installed service needs no installer invocation.
                self.reuseOrUpdateInstalledService { installResult in
                    switch installResult {
                    case .success:
                        do {
                            try self.ensureConfig(provider: "legacy")
                            runSetup()
                        } catch {
                            recover("Tesla setup failed", error, true)
                        }
                    case let .failure(error):
                        recover("Service update failed", error,
                                !Self.isForwardOnlyUpgradeFailure(error))
                    }
                }
            }
        }
    }

    static func setupInvocation(configPath: URL,
                                tokens: TeslaAuthTokens,
                                vehicleID: Int64?) throws -> HubSetupInvocation {
        let payload = try JSONSerialization.data(withJSONObject: [
            "accessToken": tokens.accessToken,
            "refreshToken": tokens.refreshToken
        ], options: [])
        guard let input = String(data: payload, encoding: .utf8) else {
            throw HubActionError.commandFailed("Could not encode Tesla login credentials.")
        }
        var arguments = ["--config", configPath.path, "setup", "--tokens-stdin"]
        if let vehicleID {
            guard vehicleID > 0 else {
                throw HubActionError.commandFailed("Tesla vehicle ID must be positive.")
            }
            arguments += ["--vehicle-id", String(vehicleID)]
        } else {
            arguments.append("--all-vehicles")
        }
        return HubSetupInvocation(arguments: arguments, standardInput: input)
    }

    static func oldCompatibleSetupInvocation(_ invocation: HubSetupInvocation) -> HubSetupInvocation {
        HubSetupInvocation(arguments: invocation.arguments.filter { $0 != "--all-vehicles" },
                           standardInput: invocation.standardInput)
    }

    static func isForwardOnlyUpgradeFailure(_ error: Error) -> Bool {
        error.localizedDescription.contains("TESLATLAS_FORWARD_ONLY_UPGRADE")
    }

    static func isProviderSwitchOutcomeAmbiguous(_ error: Error) -> Bool {
        error.localizedDescription.contains("TESLATLAS_PROVIDER_SWITCH_OUTCOME_AMBIGUOUS")
    }

    static func isMigrationOutcomeAmbiguous(_ error: Error) -> Bool {
        error.localizedDescription.contains("TESLATLAS_MIGRATION_OUTCOME_AMBIGUOUS")
    }

    static func providerSwitchStoppedError(_ error: Error) -> Error {
        HubActionError.commandFailed(
            "Tesla provider switch outcome needs verification. Hub remains stopped; run diagnostics before retrying. \(error.localizedDescription)"
        )
    }

    static func migrationStoppedError(_ error: Error) -> Error {
        let diagnostic = error.localizedDescription.lowercased()
        if diagnostic.contains("legacy refresh outcome is unresolved")
            || (diagnostic.contains("legacy")
                && diagnostic.contains("credential")
                && diagnostic.contains("consum")) {
            return HubActionError.commandFailed(
                "Sign in to Tesla again in TeslaMate, then retry the import."
            )
        }
        return HubActionError.commandFailed(
            "TeslaMate import failed; retry the import."
        )
    }

    static func migrationFailureReasonCode(_ error: Error) -> String {
        if HubAppLog.errorCode(error) == "command_timed_out" { return "timeout" }

        let diagnostic = error.localizedDescription.lowercased()
        if diagnostic.contains("timed out")
            || diagnostic.contains("timeout")
            || diagnostic.contains("deadline exceeded") {
            return "timeout"
        }
        if diagnostic.contains("no space left on device")
            || diagnostic.contains("database or disk is full")
            || diagnostic.contains("disk full")
            || diagnostic.contains("sqlite_full")
            || diagnostic.contains("storage full") {
            return "disk_space"
        }
        if diagnostic.contains("schema mismatch")
            || diagnostic.contains("schema version")
            || diagnostic.contains("incompatible schema")
            || diagnostic.contains("unsupported schema")
            || diagnostic.contains("migration version")
            || diagnostic.contains("teslamate version")
            || diagnostic.contains("requires teslamate")
            || diagnostic.contains("update teslamate") {
            return "schema_version"
        }
        if diagnostic.contains("ssh ")
            || diagnostic.contains("ssh:")
            || diagnostic.contains("ssh_")
            || diagnostic.contains("tunnel")
            || diagnostic.contains("port forwarding")
            || diagnostic.contains("could not resolve hostname") {
            return "ssh_tunnel"
        }
        if diagnostic.contains("legacy refresh")
            || diagnostic.contains("token pair")
            || diagnostic.contains("refresh token")
            || diagnostic.contains("credential")
            || diagnostic.contains("re-login") {
            return "credentials"
        }
        if diagnostic.contains("sqlite")
            || diagnostic.contains("database")
            || diagnostic.contains("postgres")
            || diagnostic.contains("catalogue")
            || diagnostic.contains("sqlx") {
            return "sqlite_database"
        }
        return "generic"
    }

    static func isAllVehiclesUnsupported(_ error: Error) -> Bool {
        let message = error.localizedDescription.lowercased()
        return message.contains("--all-vehicles")
            && (message.contains("unexpected argument")
                || message.contains("unknown option")
                || message.contains("unrecognized option"))
    }

    func startHub(completion: @escaping (Result<Void, Error>) -> Void) {
        guard !hasPendingMigrationHandover else {
            HubAppLog.shared.record("service.rejected", category: "service", level: "WARN",
                                    fields: ["action": "start", "reason": "handover_pending"])
            completion(.failure(HubActionError.commandFailed(
                "Finish the TeslaMate handover before starting Hub."
            )))
            return
        }
        runServiceCommand(["service", "start"], completion: completion)
    }

    func stopHub(completion: @escaping (Result<Void, Error>) -> Void) {
        runServiceCommand(["service", "stop"], completion: completion)
    }

    func restartHub(completion: @escaping (Result<Void, Error>) -> Void) {
        guard !hasPendingMigrationHandover else {
            HubAppLog.shared.record("service.rejected", category: "service", level: "WARN",
                                    fields: ["action": "restart", "reason": "handover_pending"])
            completion(.failure(HubActionError.commandFailed(
                "Finish the TeslaMate handover before restarting Hub."
            )))
            return
        }
        runServiceCommand(["service", "restart"], completion: completion)
    }

    func acknowledgeMigrationHandoverAndStart(completion: @escaping (Result<Void, Error>) -> Void) {
        guard !previewMode else {
            HubAppLog.shared.record("handover_start.rejected", category: "teslamate_import",
                                    level: "WARN", fields: ["reason": "preview_read_only"])
            completion(.failure(HubActionError.preview))
            return
        }
        guard let operationID = beginMigrationHandoverStart() else {
            HubAppLog.shared.record("handover_start.rejected", category: "teslamate_import",
                                    level: "WARN", fields: ["reason": "already_in_progress"])
            completion(.failure(HubActionError.commandFailed(
                "Hub startup is already in progress."
            )))
            return
        }
        let finish: (Result<Void, Error>) -> Void = { [weak self] result in
            self?.finishMigrationHandoverStart(
                operationID: operationID,
                result: result,
                completion: completion
            )
        }
        guard let handover = migrationHandoverState,
              handover.phase == .awaitingHandover else {
            HubAppLog.shared.record("handover_start.rejected", category: "teslamate_import",
                                    level: "WARN", fields: ["reason": "checks_incomplete"])
            finish(.failure(HubActionError.commandFailed(
                "Finish the migration checks before starting Hub."
            )))
            return
        }
        let started = Date()
        HubAppLog.shared.record("handover_start.requested", category: "teslamate_import")
        captureMigrationCollectorLeaseBaseline { [weak self] baseline in
            guard let self else { return }
            do {
                try self.ensureConfig(provider: handover.previousProvider,
                                      collectorIntervalSeconds: handover.previousIntervalSeconds)
            } catch {
                HubAppLog.shared.record("handover_start.failed", category: "teslamate_import",
                                        level: "ERROR", fields: [
                                        "error_code": HubAppLog.errorCode(error),
                                        "reason": "config_restore_failed"
                                    ])
                finish(.failure(error))
                return
            }
            let startRequestedAtMs = self.migrationStartupReadinessNowMilliseconds()
            let readinessDeadlineAtMs = startRequestedAtMs + Int64(
                self.migrationStartupReadinessTimeout * 1_000
            )
            self.serviceRunner.run(arguments: ["service", "start"]) { [weak self] result in
                guard let self else { return }
                switch result {
                case .success:
                    self.waitForMigrationStartupReadiness(
                        baseline: baseline,
                        startRequestedAtMs: startRequestedAtMs,
                        deadlineAtMs: readinessDeadlineAtMs,
                        collectorRequired: handover.previousIntervalSeconds > 0,
                        attemptsRemaining: self.migrationStartupReadinessMaxAttempts
                    ) { readinessResult in
                        switch readinessResult {
                        case .success:
                            self.completeMigrationHandoverStart(
                                handover: handover,
                                started: started,
                                completion: finish
                            )
                        case let .failure(readinessError):
                            self.rollbackUnreadyMigrationHandoverStart(
                                handover: handover,
                                readinessError: readinessError,
                                completion: finish
                            )
                        }
                    }
                case let .failure(startError):
                    HubAppLog.shared.record("handover_start.failed", category: "teslamate_import",
                                            level: "ERROR", fields: [
                                                "error_code": HubAppLog.errorCode(startError),
                                                "reason": "service_start_failed"
                                            ])
                    do {
                        try self.ensureConfig(provider: handover.previousProvider,
                                              collectorIntervalSeconds: 0)
                        try self.writeMigrationHandoverMarker(handover)
                        finish(.failure(startError))
                    } catch {
                        HubAppLog.shared.record("handover_recovery.failed",
                                                category: "teslamate_import", level: "ERROR",
                                                fields: [
                                                    "error_code": HubAppLog.errorCode(error),
                                                    "reason": "start_failure_rollback"
                                                ])
                        finish(.failure(HubActionError.commandFailed(
                            "Hub did not start: \(startError.localizedDescription). The collector pause could not be restored: \(error.localizedDescription)"
                        )))
                    }
                }
            }
        }
    }

    private func beginMigrationHandoverStart() -> UUID? {
        migrationHandoverStartLock.lock()
        defer { migrationHandoverStartLock.unlock() }
        guard migrationHandoverStartOperationID == nil else { return nil }
        let operationID = UUID()
        migrationHandoverStartOperationID = operationID
        return operationID
    }

    private func finishMigrationHandoverStart(
        operationID: UUID,
        result: Result<Void, Error>,
        completion: @escaping (Result<Void, Error>) -> Void
    ) {
        migrationHandoverStartLock.lock()
        guard migrationHandoverStartOperationID == operationID else {
            migrationHandoverStartLock.unlock()
            return
        }
        migrationHandoverStartOperationID = nil
        migrationHandoverStartLock.unlock()
        DispatchQueue.main.async { completion(result) }
    }

    private func captureMigrationCollectorLeaseBaseline(
        completion: @escaping (HubCollectorLeaseBaseline) -> Void
    ) {
        installedCommandRunner.run(arguments: ["--config", configPath.path, "status"]) { result in
            guard case let .success(output) = result,
                  let data = output.data(using: .utf8),
                  let root = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
                  root.keys.contains("collector"),
                  let document = try? JSONDecoder().decode(HubStartupStatusDocument.self,
                                                            from: data),
                  document.status == "ok" else {
                completion(.unavailable)
                return
            }
            guard !(root["collector"] is NSNull) else {
                completion(.observed(nil))
                return
            }
            guard let collector = document.collector, collector.isCoherent else {
                completion(.unavailable)
                return
            }
            completion(.observed(collector.instanceId))
        }
    }

    private func waitForMigrationStartupReadiness(
        baseline: HubCollectorLeaseBaseline,
        startRequestedAtMs: Int64,
        deadlineAtMs: Int64,
        collectorRequired: Bool,
        attemptsRemaining: Int,
        completion: @escaping (Result<Void, Error>) -> Void
    ) {
        guard migrationStartupReadinessNowMilliseconds() < deadlineAtMs else {
            completion(.failure(HubActionError.commandFailed(
                "Hub did not become ready before the startup deadline."
            )))
            return
        }
        installedCommandRunner.run(arguments: ["--config", configPath.path, "status"]) {
            [weak self] result in
            guard let self else { return }
            let document: HubStartupStatusDocument
            switch result {
            case .failure:
                completion(.failure(HubActionError.commandFailed(
                    "Hub readiness status could not be read."
                )))
                return
            case let .success(output):
                guard let data = output.data(using: .utf8),
                      let parsed = try? JSONDecoder().decode(HubStartupStatusDocument.self,
                                                             from: data),
                      parsed.status == "ok" else {
                    completion(.failure(HubActionError.commandFailed(
                        "Hub readiness status was invalid."
                    )))
                    return
                }
                document = parsed
            }
            if document.ready,
               self.isFreshMigrationStartupStatus(
                document,
                baseline: baseline,
                startRequestedAtMs: startRequestedAtMs,
                collectorRequired: collectorRequired
               ) {
                completion(.success(()))
                return
            }
            if document.ready, collectorRequired,
               (document.collector == nil || document.collector?.isCoherent != true) {
                completion(.failure(HubActionError.commandFailed(
                    "Hub readiness status did not include a valid collector lease."
                )))
                return
            }
            guard attemptsRemaining > 1,
                  self.migrationStartupReadinessNowMilliseconds() < deadlineAtMs else {
                completion(.failure(HubActionError.commandFailed(
                    "Hub did not become ready before the startup deadline."
                )))
                return
            }
            self.migrationStartupReadinessSchedule(self.migrationStartupReadinessPollInterval) {
                [weak self] in
                self?.waitForMigrationStartupReadiness(
                    baseline: baseline,
                    startRequestedAtMs: startRequestedAtMs,
                    deadlineAtMs: deadlineAtMs,
                    collectorRequired: collectorRequired,
                    attemptsRemaining: attemptsRemaining - 1,
                    completion: completion
                )
            }
        }
    }

    private func migrationStartupReadinessNowMilliseconds() -> Int64 {
        Int64(migrationStartupReadinessNow().timeIntervalSince1970 * 1_000)
    }

    private func isFreshMigrationStartupStatus(
        _ document: HubStartupStatusDocument,
        baseline: HubCollectorLeaseBaseline,
        startRequestedAtMs: Int64,
        collectorRequired: Bool
    ) -> Bool {
        guard collectorRequired else { return true }
        guard let collector = document.collector, collector.isCoherent else { return false }
        switch baseline {
        case let .observed(previousInstance):
            return previousInstance != collector.instanceId
        case .unavailable:
            return collector.startedAtMs >= startRequestedAtMs
        }
    }

    private func completeMigrationHandoverStart(
        handover: HubMigrationHandoverState,
        started: Date,
        completion: @escaping (Result<Void, Error>) -> Void
    ) {
        do {
            try FileManager.default.removeItem(at: migrationHandoverMarker)
            HubAppLog.shared.record("handover_start.completed",
                                    category: "teslamate_import", fields: [
                                        "duration_ms": String(Int(Date().timeIntervalSince(started) * 1000))
                                    ])
            completion(.success(()))
        } catch {
            let cleanupError = error
            HubAppLog.shared.record("handover_start.failed",
                                    category: "teslamate_import", level: "ERROR",
                                    fields: [
                                        "error_code": HubAppLog.errorCode(error),
                                        "reason": "handover_gate_cleanup_failed"
                                    ])
            serviceRunner.run(arguments: ["service", "stop"]) { _ in
                do {
                    try self.ensureConfig(provider: handover.previousProvider,
                                          collectorIntervalSeconds: 0)
                    try self.writeMigrationHandoverMarker(handover)
                } catch {
                    HubAppLog.shared.record("handover_recovery.failed",
                                            category: "teslamate_import", level: "ERROR",
                                            fields: [
                                                "error_code": HubAppLog.errorCode(error),
                                                "reason": "cleanup_failure_rollback"
                                            ])
                }
                completion(.failure(HubActionError.commandFailed(
                    "Hub was stopped because the migration handover gate could not be cleared: \(cleanupError.localizedDescription)"
                )))
            }
        }
    }

    private func rollbackUnreadyMigrationHandoverStart(
        handover: HubMigrationHandoverState,
        readinessError: Error,
        completion: @escaping (Result<Void, Error>) -> Void
    ) {
        HubAppLog.shared.record("handover_start.failed", category: "teslamate_import",
                                level: "ERROR", fields: [
                                    "error_code": HubAppLog.errorCode(readinessError),
                                    "reason": "startup_readiness_failed"
                                ])
        serviceRunner.run(arguments: ["service", "stop"]) { stopResult in
            var pauseRestored = true
            do {
                try self.ensureConfig(provider: handover.previousProvider,
                                      collectorIntervalSeconds: 0)
                try self.writeMigrationHandoverMarker(handover)
            } catch {
                pauseRestored = false
                HubAppLog.shared.record("handover_recovery.failed",
                                        category: "teslamate_import", level: "ERROR",
                                        fields: [
                                            "error_code": HubAppLog.errorCode(error),
                                            "reason": "readiness_failure_rollback"
                                        ])
            }
            let message: String
            switch (stopResult, pauseRestored) {
            case (.success, true):
                message = "Hub did not become ready and was stopped. The migration handover remains pending."
            case (.success, false):
                message = "Hub was stopped after startup failed, but the collector pause could not be restored. Keep TeslaMate disabled and try again."
            case (.failure, _):
                message = "Hub did not become ready and could not be confirmed stopped. Keep TeslaMate disabled, stop Hub, and try again."
            }
            completion(.failure(HubActionError.commandFailed(message)))
        }
    }

    func runOnboardingChecks(expectRunning: Bool,
                             completion: @escaping (Result<[HubOnboardingCheck], Error>) -> Void) {
        HubAppLog.shared.record("verification.started", category: "onboarding",
                                fields: ["expect_running": expectRunning ? "true" : "false"])
        if previewMode {
            DispatchQueue.main.async { completion(.success(Self.previewOnboardingChecks)) }
            return
        }
        if !expectRunning, migrationHandoverState != nil {
            let stopAndCheck = { [weak self] in
                guard let self else { return }
                self.serviceRunner.run(arguments: ["service", "stop"]) { stopResult in
                    switch stopResult {
                    case .success:
                        self.performOnboardingChecks(expectRunning: false,
                                                     completion: completion)
                    case let .failure(error):
                        DispatchQueue.main.async { completion(.failure(error)) }
                    }
                }
            }
            guard !isServiceInstalled else {
                stopAndCheck()
                return
            }
            installer.install { installResult in
                switch installResult {
                case .success: stopAndCheck()
                case let .failure(error):
                    DispatchQueue.main.async { completion(.failure(error)) }
                }
            }
            return
        }
        performOnboardingChecks(expectRunning: expectRunning, completion: completion)
    }

    private func performOnboardingChecks(expectRunning: Bool,
                                         completion: @escaping (Result<[HubOnboardingCheck], Error>) -> Void) {
        let finish: (Result<String, Error>) -> Void = { [weak self] doctorResult in
            guard let self else { return }
            self.logs { logText in
                // Read readiness last, so the wizard and dashboard use the same current state.
                self.refresh { snapshot in
                    let servicePassed = expectRunning
                        ? snapshot.health == .running
                        : snapshot.health == .stopped
                    let serviceDetail = expectRunning
                        ? snapshot.service
                        : (servicePassed ? "Installed and safely stopped" : snapshot.service)
                    let vehiclePassed = snapshot.vehicleName != "Vehicle"
                        && snapshot.vehicleName != "No configured vehicle"
                        && snapshot.vehicle != "No configured vehicle"
                        && snapshot.vehicle != "Unknown"
                    let doctorPassed: Bool
                    let doctorDetail: String
                    switch doctorResult {
                    case .success:
                        doctorPassed = !expectRunning || servicePassed
                        doctorDetail = expectRunning
                            ? (servicePassed ? "Live readiness passed; full integrity check available in Diagnostics"
                               : "Hub is not ready yet. Wait a moment, then run again.")
                            : "Passed"
                    case let .failure(error):
                        doctorPassed = false
                        doctorDetail = Self.conciseDiagnostic(error.localizedDescription)
                    }
                    let noLogsYet = logText.hasPrefix("No Hub logs are available yet.")
                    let logsPassed = expectRunning ? !noLogsYet && !logText.isEmpty : true
                    let logsDetail = noLogsYet
                        ? (expectRunning ? "No logs yet" : "No service logs while stopped")
                        : (logText.isEmpty ? "Unavailable" : "Readable")
                    let checks = [
                        HubOnboardingCheck(title: "Service", detail: serviceDetail, passed: servicePassed),
                        HubOnboardingCheck(title: "Tesla account", detail: snapshot.account,
                                           passed: snapshot.account == "Connected"),
                        HubOnboardingCheck(title: "Vehicle", detail: snapshot.vehicleName,
                                           passed: vehiclePassed),
                        HubOnboardingCheck(title: "Database", detail: snapshot.database,
                                           passed: snapshot.database.hasPrefix("Healthy")),
                        HubOnboardingCheck(title: "Diagnostics", detail: doctorDetail,
                                           passed: doctorPassed),
                        HubOnboardingCheck(title: "Logs",
                                           detail: logsDetail,
                                           passed: logsPassed)
                    ]
                    guard !expectRunning,
                          checks.allSatisfy(\.passed),
                          var handover = self.migrationHandoverState else {
                        HubAppLog.shared.record(
                            "verification.completed",
                            category: "onboarding",
                            fields: [
                                "passed": checks.allSatisfy(\.passed) ? "true" : "false",
                                "failed_checks": checks.filter { !$0.passed }.map(\.title).joined(separator: ",")
                            ]
                        )
                        completion(.success(checks))
                        return
                    }
                    handover.phase = .awaitingHandover
                    do {
                        try self.writeMigrationHandoverMarker(handover)
                        HubAppLog.shared.record("verification.completed", category: "onboarding",
                                                fields: ["handover": "awaiting_user", "passed": "true"])
                        completion(.success(checks))
                    } catch {
                        HubAppLog.shared.record("verification.failed", category: "onboarding",
                                                level: "ERROR",
                                                fields: ["error_code": HubAppLog.errorCode(error)])
                        completion(.failure(error))
                    }
                }
            }
        }
        if expectRunning {
            // Immutable doctor requires a stopped writer. Status opens the live database
            // read-only and checks readiness without pausing collection or calling Tesla.
            finish(.success(""))
        } else {
            let runner = isServiceInstalled ? installedCommandRunner : commandRunner
            runner.run(arguments: ["--config", configPath.path, "doctor"], completion: finish)
        }
    }

    private static func conciseDiagnostic(_ message: String) -> String {
        let line = message.split(whereSeparator: { $0.isNewline }).first.map(String.init)
            ?? "Failed"
        return String(line.prefix(160))
    }

    func performVehicleControl(_ action: HubVehicleControl,
                               vehicleID requestedVehicleID: UUID? = nil,
                               completion: @escaping (Result<Void, Error>) -> Void) {
        guard !previewMode else {
            HubAppLog.shared.record("command.rejected", category: "vehicle_control", level: "WARN",
                                    fields: ["action": action.rawValue, "reason": "preview_read_only"])
            completion(.failure(HubActionError.preview))
            return
        }
        guard snapshot.health == .running else {
            HubAppLog.shared.record("command.rejected", category: "vehicle_control", level: "WARN",
                                    fields: ["action": action.rawValue, "reason": "service_not_running"])
            completion(.failure(HubActionError.commandFailed("Hub must be running before sending a vehicle command.")))
            return
        }
        guard snapshot.account == "Connected" else {
            HubAppLog.shared.record("command.rejected", category: "vehicle_control", level: "WARN",
                                    fields: ["action": action.rawValue, "reason": "account_disconnected"])
            completion(.failure(HubActionError.commandFailed("Connect Tesla before sending a vehicle command.")))
            return
        }
        guard snapshot.provider == .fleet else {
            HubAppLog.shared.record("command.rejected", category: "vehicle_control", level: "WARN",
                                    fields: ["action": action.rawValue,
                                             "reason": "provider_does_not_support_commands"])
            completion(.failure(HubActionError.commandFailed(
                "Vehicle controls require Tesla Fleet API."
            )))
            return
        }
        guard let vehicleID = requestedVehicleID ?? snapshot.controlVehicleID else {
            HubAppLog.shared.record("command.rejected", category: "vehicle_control", level: "WARN",
                                    fields: ["action": action.rawValue, "reason": "vehicle_not_selected"])
            completion(.failure(HubActionError.commandFailed("Choose a vehicle before sending a command.")))
            return
        }
        guard snapshot.controlVehicles.contains(where: { $0.id == vehicleID }) else {
            HubAppLog.shared.record("command.rejected", category: "vehicle_control", level: "WARN",
                                    fields: ["action": action.rawValue, "reason": "vehicle_stale"])
            completion(.failure(HubActionError.commandFailed("The selected vehicle is no longer configured.")))
            return
        }
        let started = Date()
        HubAppLog.shared.record("command.requested", category: "vehicle_control",
                                fields: ["action": action.rawValue])
        let runner = isServiceInstalled ? installedCommandRunner : commandRunner
        let arguments = ["--config", configPath.path, "control", "--vehicle-id",
                         vehicleID.uuidString.lowercased(), action.rawValue, "--confirm"]
        runner.run(arguments: arguments) { result in
            DispatchQueue.main.async {
                switch result {
                case .success:
                    HubAppLog.shared.record("command.accepted", category: "vehicle_control",
                                            fields: [
                                                "action": action.rawValue,
                                                "duration_ms": String(Int(Date().timeIntervalSince(started) * 1000))
                                            ])
                    completion(.success(()))
                case let .failure(error):
                    HubAppLog.shared.record("command.failed", category: "vehicle_control", level: "ERROR",
                                            fields: [
                                                "action": action.rawValue,
                                                "duration_ms": String(Int(Date().timeIntervalSince(started) * 1000)),
                                                "error_code": HubAppLog.errorCode(error)
                                            ])
                    completion(.failure(error))
                }
            }
        }
    }

    func logs(maximumBytes: Int = 128 * 1024, completion: @escaping (String) -> Void) {
        if previewMode {
            completion("Preview mode\n\n[INFO] Teslatlas Hub is running in the background.\n[INFO] Vehicle went offline\n[INFO] Position stored\n")
            return
        }
        DispatchQueue.global(qos: .utility).async {
            let folder = self.homeDirectory.appendingPathComponent("Library/Logs/Teslatlas Hub", isDirectory: true)
            let files = [
                ("hub.out.log", folder.appendingPathComponent("hub.out.log")),
                ("hub.err.log", folder.appendingPathComponent("hub.err.log"))
            ]
            let contents = files.compactMap { name, url in
                Self.logTail(of: url, maximumBytes: maximumBytes).map { tail in
                    let attributes = try? FileManager.default.attributesOfItem(atPath: url.path)
                    let modified = attributes?[.modificationDate] as? Date
                    let timestamp = modified.map { ISO8601DateFormatter().string(from: $0) } ?? "unknown"
                    return "File last written: \(timestamp). This file may contain historical errors, not current service status.\n== \(name) ==\n\(tail)"
                }
            }
            let text = contents.isEmpty ? "No Hub logs are available yet.\n" : contents.joined(separator: "\n")
            DispatchQueue.main.async { completion(text) }
        }
    }

    func diagnostics() -> [String] {
        snapshot.diagnosticLines
    }

    func runFullDiagnostics(completion: @escaping (String) -> Void) {
        if previewMode {
            completion("Preview mode\n\n" + supportMetadata() + "\n\n"
                + snapshot.diagnosticLines.joined(separator: "\n"))
            return
        }
        serviceRunner.loadedState { [weak self] state in
            guard let self else { return }
            switch state {
            case .loaded:
                self.serviceRunner.run(arguments: ["service", "stop"]) { stopResult in
                    switch stopResult {
                    case .success:
                        self.runFullDiagnosticsWhileStopped { report in
                            self.serviceRunner.run(arguments: ["service", "start"]) { startResult in
                                completion(report + "\n\n" + Self.serviceResumeSection(startResult))
                            }
                        }
                    case let .failure(error):
                        self.runFullDiagnosticsWhileStopped { report in
                            completion(Self.servicePauseFailureSection(error) + "\n\n" + report)
                        }
                    }
                }
            case .unloaded:
                self.runFullDiagnosticsWhileStopped(completion: completion)
            case let .unknown(error):
                self.runFullDiagnosticsWhileStopped { report in
                    completion(Self.serviceStateFailureSection(error) + "\n\n" + report)
                }
            }
        }
    }

    private static func servicePauseFailureSection(_ error: Error) -> String {
        "== service pause (failed) ==\n\(error.localizedDescription)"
    }

    private static func serviceStateFailureSection(_ error: Error) -> String {
        "== service state check (failed) ==\n\(error.localizedDescription)"
    }

    private static func serviceResumeSection(_ result: Result<String, Error>) -> String {
        switch result {
        case .success:
            return "== service resume ==\nHub collection resumed."
        case let .failure(error):
            return "== service resume (failed) ==\n\(error.localizedDescription)"
        }
    }

    private func runFullDiagnosticsWhileStopped(completion: @escaping (String) -> Void) {
        let diagnosticsStarted = Date()
        HubAppLog.shared.record("checks.started", category: "diagnostics")
        let runner = isServiceInstalled ? installedCommandRunner : commandRunner
        let config = ["--config", configPath.path]
        func section(_ title: String,
                     _ result: Result<String, Error>,
                     durationMilliseconds: Int) -> String {
            switch result {
            case let .success(output):
                return "== \(title) ==\nDuration: \(durationMilliseconds) ms\n"
                    + "\(output.trimmingCharacters(in: .whitespacesAndNewlines))\n"
            case let .failure(error):
                return "== \(title) (failed) ==\nDuration: \(durationMilliseconds) ms\n"
                    + "\(error.localizedDescription)\n"
            }
        }
        let doctorStarted = Date()
        runner.run(arguments: config + ["doctor"]) { doctor in
            let doctorMilliseconds = Int(Date().timeIntervalSince(doctorStarted) * 1000)
            let preflightStarted = Date()
            runner.run(arguments: config + ["preflight"]) { preflight in
                let preflightMilliseconds = Int(Date().timeIntervalSince(preflightStarted) * 1000)
                let statusStarted = Date()
                runner.run(arguments: config + ["status"]) { status in
                    let statusMilliseconds = Int(Date().timeIntervalSince(statusStarted) * 1000)
                    let logsStarted = Date()
                    self.logs(maximumBytes: 512 * 1024) { logText in
                        let logsMilliseconds = Int(Date().timeIntervalSince(logsStarted) * 1000)
                        let failedSections = [doctor, preflight, status].reduce(into: 0) { count, result in
                            if case .failure = result { count += 1 }
                        }
                        let report = [
                            "Teslatlas Hub diagnostics",
                            "TeslaMate is not written. Stored Owner and Fleet tokens are not deleted.",
                            "",
                            self.supportMetadata(),
                            "",
                            section("doctor — Hub database, tokens, TLS, collector", doctor,
                                    durationMilliseconds: doctorMilliseconds),
                            section("preflight — selected provider credentials", preflight,
                                    durationMilliseconds: preflightMilliseconds),
                            section("status — vehicles and credential presence", status,
                                    durationMilliseconds: statusMilliseconds),
                            "== recent logs ==",
                            "Read duration: \(logsMilliseconds) ms",
                            logText.trimmingCharacters(in: .whitespacesAndNewlines)
                        ].joined(separator: "\n")
                        HubAppLog.shared.record(
                            "checks.completed",
                            category: "diagnostics",
                            level: failedSections == 0 ? "INFO" : "WARN",
                            fields: [
                                "duration_ms": String(Int(Date().timeIntervalSince(diagnosticsStarted) * 1000)),
                                "failed_sections": String(failedSections),
                                "doctor_ms": String(doctorMilliseconds),
                                "logs_ms": String(logsMilliseconds),
                                "preflight_ms": String(preflightMilliseconds),
                                "status_ms": String(statusMilliseconds)
                            ]
                        )
                        completion(report)
                    }
                }
            }
        }
    }

    private func supportMetadata() -> String {
        let bundle = Bundle.main
        let appVersion = bundle.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String
            ?? "development"
        let appBuild = bundle.object(forInfoDictionaryKey: "CFBundleVersion") as? String
            ?? "development"
        let provider = snapshot.provider?.displayName ?? "Not configured"
        let serviceState: String
        switch snapshot.health {
        case .running: serviceState = "running"
        case .stopped: serviceState = "stopped"
        case .needsInstall: serviceState = "not installed"
        case .degraded: serviceState = "needs attention"
        }
#if arch(arm64)
        let architecture = "arm64"
#elseif arch(x86_64)
        let architecture = "x86_64"
#else
        let architecture = "unknown"
#endif
        let availableStorage: String
        if let bytes = try? homeDirectory.resourceValues(
            forKeys: [.volumeAvailableCapacityForImportantUsageKey]
        ).volumeAvailableCapacityForImportantUsage {
            availableStorage = ByteCountFormatter.string(fromByteCount: bytes, countStyle: .file)
        } else {
            availableStorage = "Unavailable"
        }
        return [
            "== support metadata ==",
            "Generated: \(ISO8601DateFormatter().string(from: Date()))",
            "App: \(appVersion) (\(appBuild))",
            "Expected Hub: \(HubRelease.bundledVersion)",
            "Observed Hub: \(snapshot.version)",
            "Service: \(serviceState)",
            "Provider: \(provider)",
            "macOS: \(ProcessInfo.processInfo.operatingSystemVersionString)",
            "Architecture: \(architecture)",
            "Available storage: \(availableStorage)"
        ].joined(separator: "\n")
    }

    func showDataFolder() {
        guard !previewMode, let dataDirectory = snapshot.dataDirectory else { return }
        NSWorkspace.shared.open(dataDirectory)
    }

    private func runServiceCommand(_ arguments: [String], completion: @escaping (Result<Void, Error>) -> Void) {
        guard !previewMode else { completion(.failure(HubActionError.preview)); return }
        let action = arguments.last ?? "unknown"
        HubAppLog.shared.record("service.requested", category: "service",
                                fields: ["action": action])
        serviceRunner.run(arguments: arguments) { result in
            DispatchQueue.main.async {
                switch result {
                case .success:
                    HubAppLog.shared.record("service.completed", category: "service",
                                            fields: ["action": action])
                    completion(.success(()))
                case let .failure(error):
                    HubAppLog.shared.record("service.failed", category: "service", level: "ERROR",
                                            fields: [
                                                "action": action,
                                                "error_code": HubAppLog.errorCode(error)
                                            ])
                    completion(.failure(error))
                }
            }
        }
    }

    private var isServiceInstalled: Bool {
        if let serviceInstalledOverride { return serviceInstalledOverride }
        let binary = "/Library/Application Support/Teslatlas Hub/bin/teslatlas-hub"
        let plist = homeDirectory.appendingPathComponent("Library/LaunchAgents/com.teslatlas.hub.plist").path
        return FileManager.default.isExecutableFile(atPath: binary) && FileManager.default.fileExists(atPath: plist)
    }

    private var configPath: URL {
        homeDirectory
            .appendingPathComponent("Library/Application Support/Teslatlas Hub", isDirectory: true)
            .appendingPathComponent("config.toml")
    }

    private var dataDirectory: URL { configPath.deletingLastPathComponent().appendingPathComponent("data", isDirectory: true) }

    private var migrationHandoverMarker: URL {
        configPath.deletingLastPathComponent().appendingPathComponent(".teslamate-handover-pending")
    }

    private var migrationHandoverState: HubMigrationHandoverState? {
        guard FileManager.default.fileExists(atPath: migrationHandoverMarker.path) else {
            return nil
        }
        guard let values = try? migrationHandoverMarker.resourceValues(
            forKeys: [.isRegularFileKey, .isSymbolicLinkKey, .fileSizeKey]
        ), values.isRegularFile == true, values.isSymbolicLink != true,
              let size = values.fileSize, size <= 4_096,
              let data = HubAppLog.regularFileData(of: migrationHandoverMarker,
                                                   maximumBytes: 4_096),
              let state = try? JSONDecoder().decode(HubMigrationHandoverState.self, from: data) else {
            // An unreadable marker remains a safe gate and resumes at verification.
            return HubMigrationHandoverState(phase: .awaitingVerification,
                                              previousIntervalSeconds: 60,
                                              previousProvider: nil)
        }
        return state
    }

    private func writeMigrationHandoverMarker(_ state: HubMigrationHandoverState) throws {
        let folder = configPath.deletingLastPathComponent()
        try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
        let data = try JSONEncoder().encode(state)
        try data.write(to: migrationHandoverMarker, options: .atomic)
        try FileManager.default.setAttributes([.posixPermissions: NSNumber(value: 0o600)],
                                              ofItemAtPath: migrationHandoverMarker.path)
    }

    private func configuredCollectorIntervalSeconds() -> Int {
        guard let content = try? readConfigIfPresent(),
              let configured = Self.collectorIntervalSeconds(in: content),
              configured > 0 else { return 60 }
        return configured
    }

    private func configuredCollectorProvider() -> String? {
        guard let content = try? readConfigIfPresent() else {
            return nil
        }
        return Self.collectorProvider(in: content)
    }

    private func readConfigIfPresent() throws -> String? {
        let descriptor = Darwin.open(configPath.path,
                                     O_RDONLY | O_CLOEXEC | O_NOFOLLOW | O_NONBLOCK)
        guard descriptor >= 0 else {
            if errno == ENOENT { return nil }
            throw HubActionError.commandFailed("Hub configuration is not a regular file.")
        }
        defer { Darwin.close(descriptor) }

        var information = stat()
        guard fstat(descriptor, &information) == 0,
              information.st_mode & S_IFMT == S_IFREG else {
            throw HubActionError.commandFailed("Hub configuration is not a regular file.")
        }
        let maximumBytes = 1024 * 1024
        guard information.st_size >= 0, information.st_size <= off_t(maximumBytes) else {
            throw HubActionError.commandFailed("Hub configuration is too large.")
        }
        var data = Data()
        var buffer = [UInt8](repeating: 0, count: 16 * 1024)
        while true {
            let count = buffer.withUnsafeMutableBytes { bytes in
                Darwin.read(descriptor, bytes.baseAddress, bytes.count)
            }
            if count == 0 { break }
            if count < 0 {
                if errno == EINTR { continue }
                throw HubActionError.commandFailed("Hub configuration could not be read.")
            }
            guard data.count + count <= maximumBytes else {
                throw HubActionError.commandFailed("Hub configuration is too large.")
            }
            data.append(contentsOf: buffer.prefix(count))
        }
        guard let content = String(data: data, encoding: .utf8) else {
            throw HubActionError.commandFailed("Hub configuration must use UTF-8 text.")
        }
        return content
    }

    private func ensureConfig(provider: String? = nil,
                              collectorIntervalSeconds: Int? = nil) throws {
        let manager = FileManager.default
        let configFolder = configPath.deletingLastPathComponent()
        try manager.createDirectory(at: configFolder, withIntermediateDirectories: true)
        try manager.setAttributes([.posixPermissions: NSNumber(value: 0o700)], ofItemAtPath: configFolder.path)
        try manager.createDirectory(at: dataDirectory, withIntermediateDirectories: true)
        try manager.setAttributes([.posixPermissions: NSNumber(value: 0o700)], ofItemAtPath: dataDirectory.path)
        if let original = try readConfigIfPresent() {
            var updated = Self.addOfflineDefaults(to: original)
            if let provider {
                updated = Self.settingCollectorProvider(provider, in: updated)
            }
            if let collectorIntervalSeconds {
                updated = Self.settingCollectorInterval(collectorIntervalSeconds, in: updated)
            }
            if updated != original {
                try Data(updated.utf8).write(to: configPath, options: .atomic)
                try manager.setAttributes([.posixPermissions: NSNumber(value: 0o600)], ofItemAtPath: configPath.path)
            }
            return
        }
        var collectorBlock = ""
        if provider != nil || collectorIntervalSeconds != nil {
            collectorBlock = "\n[collector]\n"
            if let provider { collectorBlock += "provider = \"\(provider)\"\n" }
            if let collectorIntervalSeconds {
                collectorBlock += "interval_seconds = \(collectorIntervalSeconds)\n"
            }
        }
        let content = """
        data_dir = \(Self.tomlBasicString(dataDirectory.path))
        bind = "127.0.0.1:8080"
        \(collectorBlock)

        [geocoder]
        enabled = false

        [terrain]
        enabled = false
        """ + "\n"
        let temporary = configFolder.appendingPathComponent(".config.\(UUID().uuidString).tmp")
        try Data(content.utf8).write(to: temporary)
        try manager.setAttributes([.posixPermissions: NSNumber(value: 0o600)], ofItemAtPath: temporary.path)
        do { try manager.moveItem(at: temporary, to: configPath) }
        catch { try? manager.removeItem(at: temporary); throw error }
    }

    private func restoreConfig(_ content: String?) throws {
        guard let content else { return }
        try Data(content.utf8).write(to: configPath, options: .atomic)
        try FileManager.default.setAttributes([.posixPermissions: NSNumber(value: 0o600)],
                                              ofItemAtPath: configPath.path)
    }

    private func unwindFailedImport(originalConfig: String?) throws {
        if let originalConfig {
            try restoreConfig(originalConfig)
        } else if FileManager.default.fileExists(atPath: configPath.path) {
            let values = try configPath.resourceValues(forKeys: [.isRegularFileKey, .isSymbolicLinkKey])
            guard values.isRegularFile == true, values.isSymbolicLink != true else {
                throw HubActionError.commandFailed(
                    "Hub configuration recovery refused to remove a replaced configuration path."
                )
            }
            try FileManager.default.removeItem(at: configPath)
        }
        if FileManager.default.fileExists(atPath: migrationHandoverMarker.path) {
            try FileManager.default.removeItem(at: migrationHandoverMarker)
        }
    }

    private func recoverFailedImport(_ importError: Error, originalConfig: String?) -> Error {
        do {
            try unwindFailedImport(originalConfig: originalConfig)
            return importError
        } catch let recoveryError {
            let safetyState = hasPendingMigrationHandover
                ? "The migration safety marker remains and Hub must stay stopped."
                : "Hub must stay stopped until its configuration is repaired."
            return HubActionError.commandFailed(
                "TeslaMate import failed: \(importError.localizedDescription) Configuration recovery also failed: \(recoveryError.localizedDescription) \(safetyState)"
            )
        }
    }

    static func settingCollectorProvider(_ provider: String, in content: String) -> String {
        precondition(provider == "legacy" || provider == "fleet")
        var lines = content.split(separator: "\n", omittingEmptySubsequences: false).map(String.init)

        func uncommented(_ line: String) -> String {
            String(line.split(separator: "#", maxSplits: 1, omittingEmptySubsequences: false)[0])
                .trimmingCharacters(in: .whitespacesAndNewlines)
        }
        func isTableHeader(_ line: String) -> Bool {
            let value = uncommented(line)
            return value.hasPrefix("[") && value.contains("]")
        }

        if let table = lines.firstIndex(where: { uncommented($0) == "[collector]" }) {
            let end = lines[(table + 1)...].firstIndex(where: isTableHeader) ?? lines.endIndex
            if let setting = lines[(table + 1)..<end].firstIndex(where: { line in
                let value = uncommented(line)
                guard let equals = value.firstIndex(of: "=") else { return false }
                return value[..<equals].trimmingCharacters(in: .whitespaces) == "provider"
            }) {
                let indentation = String(lines[setting].prefix { $0 == " " || $0 == "\t" })
                lines[setting] = "\(indentation)provider = \"\(provider)\""
            } else {
                lines.insert("provider = \"\(provider)\"", at: table + 1)
            }
        } else {
            if !lines.isEmpty && lines.last != "" { lines.append("") }
            lines.append("[collector]")
            lines.append("provider = \"\(provider)\"")
        }
        if content.hasSuffix("\n") && lines.last != "" { lines.append("") }
        return lines.joined(separator: "\n")
    }

    static func collectorProvider(in content: String) -> String? {
        let lines = content.split(separator: "\n", omittingEmptySubsequences: false).map(String.init)
        func uncommented(_ line: String) -> String {
            String(line.split(separator: "#", maxSplits: 1, omittingEmptySubsequences: false)[0])
                .trimmingCharacters(in: .whitespacesAndNewlines)
        }
        func isTableHeader(_ line: String) -> Bool {
            let value = uncommented(line)
            return value.hasPrefix("[") && value.contains("]")
        }
        guard let table = lines.firstIndex(where: { uncommented($0) == "[collector]" }) else {
            return nil
        }
        let end = lines[(table + 1)...].firstIndex(where: isTableHeader) ?? lines.endIndex
        for line in lines[(table + 1)..<end] {
            let value = uncommented(line)
            guard let equals = value.firstIndex(of: "="),
                  value[..<equals].trimmingCharacters(in: .whitespaces) == "provider" else {
                continue
            }
            let raw = value[value.index(after: equals)...]
                .trimmingCharacters(in: .whitespacesAndNewlines)
                .trimmingCharacters(in: CharacterSet(charactersIn: "\""))
            if raw == "legacy" || raw == "fleet" {
                return raw
            }
            return nil
        }
        return nil
    }

    static func collectorIntervalSeconds(in content: String) -> Int? {
        let lines = content.split(separator: "\n", omittingEmptySubsequences: false).map(String.init)
        func uncommented(_ line: String) -> String {
            String(line.split(separator: "#", maxSplits: 1, omittingEmptySubsequences: false)[0])
                .trimmingCharacters(in: .whitespacesAndNewlines)
        }
        func isTableHeader(_ line: String) -> Bool {
            let value = uncommented(line)
            return value.hasPrefix("[") && value.contains("]")
        }
        guard let table = lines.firstIndex(where: { uncommented($0) == "[collector]" }) else {
            return nil
        }
        let end = lines[(table + 1)...].firstIndex(where: isTableHeader) ?? lines.endIndex
        for line in lines[(table + 1)..<end] {
            let value = uncommented(line)
            guard let equals = value.firstIndex(of: "="),
                  value[..<equals].trimmingCharacters(in: .whitespaces) == "interval_seconds" else {
                continue
            }
            return Int(value[value.index(after: equals)...].trimmingCharacters(in: .whitespaces))
        }
        return nil
    }

    static func settingCollectorInterval(_ seconds: Int, in content: String) -> String {
        precondition(seconds >= 0)
        var lines = content.split(separator: "\n", omittingEmptySubsequences: false).map(String.init)
        func uncommented(_ line: String) -> String {
            String(line.split(separator: "#", maxSplits: 1, omittingEmptySubsequences: false)[0])
                .trimmingCharacters(in: .whitespacesAndNewlines)
        }
        func isTableHeader(_ line: String) -> Bool {
            let value = uncommented(line)
            return value.hasPrefix("[") && value.contains("]")
        }
        if let table = lines.firstIndex(where: { uncommented($0) == "[collector]" }) {
            let end = lines[(table + 1)...].firstIndex(where: isTableHeader) ?? lines.endIndex
            if let setting = lines[(table + 1)..<end].firstIndex(where: { line in
                let value = uncommented(line)
                guard let equals = value.firstIndex(of: "=") else { return false }
                return value[..<equals].trimmingCharacters(in: .whitespaces) == "interval_seconds"
            }) {
                let indentation = String(lines[setting].prefix { $0 == " " || $0 == "\t" })
                lines[setting] = "\(indentation)interval_seconds = \(seconds)"
            } else {
                lines.insert("interval_seconds = \(seconds)", at: table + 1)
            }
        } else {
            if !lines.isEmpty && lines.last != "" { lines.append("") }
            lines.append("[collector]")
            lines.append("interval_seconds = \(seconds)")
        }
        if content.hasSuffix("\n") && lines.last != "" { lines.append("") }
        return lines.joined(separator: "\n")
    }

    static func addOfflineDefaults(to content: String) -> String {
        var lines = content.split(separator: "\n", omittingEmptySubsequences: false).map(String.init)

        func uncommented(_ line: String) -> String {
            String(line.split(separator: "#", maxSplits: 1, omittingEmptySubsequences: false)[0])
                .trimmingCharacters(in: .whitespacesAndNewlines)
        }
        func isTableHeader(_ line: String) -> Bool {
            let value = uncommented(line)
            return value.hasPrefix("[") && value.contains("]")
        }
        func hasEnabled(from start: Int, to end: Int) -> Bool {
            guard start < end else { return false }
            return lines[start..<end].contains { line in
                let value = uncommented(line)
                guard value.hasPrefix("enabled") else { return false }
                return value.dropFirst("enabled".count)
                    .trimmingCharacters(in: .whitespaces).hasPrefix("=")
            }
        }

        var changed = false
        for name in ["geocoder", "terrain"] {
            if let table = lines.firstIndex(where: { uncommented($0) == "[\(name)]" }) {
                let end = lines[(table + 1)...].firstIndex(where: isTableHeader) ?? lines.endIndex
                if !hasEnabled(from: table + 1, to: end) {
                    lines.insert("enabled = false", at: table + 1)
                    changed = true
                }
            } else {
                if !lines.isEmpty && lines.last != "" { lines.append("") }
                lines.append("[\(name)]")
                lines.append("enabled = false")
                changed = true
            }
        }
        guard changed else { return content }
        if content.hasSuffix("\n") && lines.last != "" { lines.append("") }
        return lines.joined(separator: "\n")
    }

    static func tomlBasicString(_ value: String) -> String {
        var encoded = "\""
        for scalar in value.unicodeScalars {
            switch scalar.value {
            case 0x08: encoded += "\\b"
            case 0x09: encoded += "\\t"
            case 0x0A: encoded += "\\n"
            case 0x0C: encoded += "\\f"
            case 0x0D: encoded += "\\r"
            case 0x22: encoded += "\\\""
            case 0x5C: encoded += "\\\\"
            case 0x00...0x1F, 0x7F:
                encoded += String(format: "\\u%04X", scalar.value)
            default:
                encoded.unicodeScalars.append(scalar)
            }
        }
        encoded += "\""
        return encoded
    }

    static func logTail(of url: URL, maximumBytes: Int) -> String? {
        HubAppLog.regularFileTail(of: url, maximumBytes: maximumBytes)
    }

    private func parseStatus(_ output: String) -> HubSnapshot? {
        guard let data = output.data(using: .utf8),
              let root = try? JSONSerialization.jsonObject(with: data) as? [String: Any] else { return nil }
        let database = root["database"] as? [String: Any]
        let vehicles = root["vehicles"] as? [[String: Any]] ?? []
        let vehicle = root["vehicle"] as? [String: Any] ?? vehicles.first
        let credentials = root["credentials"] as? [String: Any]
        let ready = root["ready"] as? Bool ?? false
        let vehicleName = vehicles.count > 1
            ? "\(vehicles.count) vehicles"
            : vehicle?["displayName"] as? String ?? "No configured vehicle"
        let vehicleSummary: String
        if let observed = vehicle?["latestObservedAtMs"] as? NSNumber {
            vehicleSummary = "Last seen \(relativeAge(milliseconds: observed.int64Value))"
        } else {
            vehicleSummary = vehicle == nil ? "No configured vehicle" : "No observations yet"
        }
        let controlVehicleID = vehicles.count == 1
            ? (vehicles[0]["vehicleId"] as? String).flatMap(UUID.init(uuidString:))
            : nil
        let controlVehicles = vehicles.compactMap { vehicle -> HubControlVehicle? in
            guard let idValue = vehicle["vehicleId"] as? String,
                  let id = UUID(uuidString: idValue) else { return nil }
            let name = (vehicle["displayName"] as? String)?.trimmingCharacters(in: .whitespacesAndNewlines)
            let displayName = name.flatMap { $0.isEmpty ? nil : $0 } ?? "Vehicle"
            let status: String
            if let observed = vehicle["latestObservedAtMs"] as? NSNumber {
                status = "Last seen \(relativeAge(milliseconds: observed.int64Value))"
            } else {
                status = "No observations yet"
            }
            return HubControlVehicle(id: id, displayName: displayName, status: status)
        }
        let dbBytes = database?["bytes"] as? NSNumber
        let dbText = dbBytes.map { "Healthy · \($0.int64Value / 1_048_576) MB" } ?? "Waiting for setup or import"
        let dataDirectory = (database?["path"] as? String).map { URL(fileURLWithPath: $0).deletingLastPathComponent() }
        let service = ready ? "Installed and running" : "Installed · needs attention"
        let providerValue = root["provider"] as? String
        let configuredProvider = providerValue.flatMap(HubAccountProvider.init(rawValue:))
        let legacy = root["legacyCredentials"] as? [String: Any]
        let fleet = root["fleetCredentials"] as? [String: Any]
        let selectedPresent = credentials?["present"] as? Bool == true
        let legacyPresent = legacy?["present"] as? Bool == true
        let fleetPresent = fleet?["present"] as? Bool == true
        let provider: HubAccountProvider?
        if selectedPresent {
            provider = configuredProvider
        } else if legacyPresent != fleetPresent {
            provider = legacyPresent ? .legacy : .fleet
        } else {
            provider = configuredProvider
        }
        let account = (selectedPresent || legacyPresent || fleetPresent)
            ? "Connected"
            : "Not configured"
        let fleetScope = fleet?["scopeStatus"] as? String
        var diagnosticLines = [
            "Service: \(service)",
            "Account: \(account)",
            "Vehicle: \(vehicleSummary)",
            "Database: \(dbText)",
            "Readiness: \(root["readinessReason"] as? String ?? "ready")",
            "Provider: \(providerValue ?? "unknown")",
            "Owner tokens: \(legacyPresent ? "present" : "absent")",
            "Fleet tokens: \(fleetPresent ? "present" : "absent")"
        ]
        if let fleetScope {
            diagnosticLines.append("Fleet scopes: \(fleetScope)")
        }
        return HubSnapshot(health: ready ? .running : .degraded,
                           service: service,
                           account: account,
                           provider: provider,
                           vehicleName: vehicleName,
                           vehicle: vehicleSummary,
                           controlVehicleID: controlVehicleID,
                           controlVehicles: controlVehicles,
                           database: dbText,
                           activity: [],
                           version: root["version"] as? String ?? HubRelease.fallbackVersion,
                           dataDirectory: dataDirectory,
                           diagnosticLines: diagnosticLines)
    }

    private func statusSnapshot(_ status: HubSnapshot, installed: Bool, loaded: HubServiceLoadState) -> HubSnapshot {
        guard installed else { return HubSnapshot(health: .needsInstall, service: "Not installed", account: status.account, provider: status.provider, vehicleName: status.vehicleName, vehicle: status.vehicle, controlVehicleID: nil, controlVehicles: status.controlVehicles, database: status.database, activity: status.activity, version: status.version, dataDirectory: status.dataDirectory ?? dataDirectory, diagnosticLines: status.diagnosticLines) }
        var result = status
        switch loaded {
        case .loaded:
            result.health = status.health == .running ? .running : .degraded
            result.service = status.health == .running ? "Installed and running" : "Installed · needs attention"
        case .unloaded:
            result.health = .stopped
            result.service = "Installed but stopped"
        case .unknown:
            result.health = .degraded
            result.service = "Installed · service state unavailable"
        }
        if status.version != HubRelease.bundledVersion {
            result.diagnosticLines.insert(
                "Version mismatch: service \(status.version), app \(HubRelease.bundledVersion)",
                at: 0
            )
            if case .loaded = loaded {
                result.health = .degraded
                result.service = "Installed · version mismatch"
            }
        }
        return result
    }

    private func fallbackSnapshot(installed: Bool, loaded: HubServiceLoadState) -> HubSnapshot {
        guard installed else { return .firstRun }
        let health: HubHealth
        let service: String
        switch loaded {
        case .loaded: health = .degraded; service = "Installed · status unavailable"
        case .unloaded: health = .stopped; service = "Installed but stopped"
        case .unknown: health = .degraded; service = "Installed · service state unavailable"
        }
        return HubSnapshot(health: health, service: service, account: "Unknown", provider: nil, vehicleName: "Vehicle", vehicle: "Unknown", controlVehicleID: nil, controlVehicles: [], database: "Unknown", activity: [], version: HubRelease.fallbackVersion, dataDirectory: dataDirectory, diagnosticLines: [service, "Hub status command did not return a valid report."])
    }

    private func relativeAge(milliseconds: Int64) -> String {
        let seconds = max(0, Int(Date().timeIntervalSince1970 - Double(milliseconds) / 1_000))
        if seconds < 60 { return "just now" }
        if seconds < 3_600 { return "\(seconds / 60) minutes ago" }
        if seconds < 86_400 { return "\(seconds / 3_600) hours ago" }
        return "\(seconds / 86_400) days ago"
    }
}
