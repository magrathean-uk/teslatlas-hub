#!/bin/sh
# SPDX-License-Identifier: AGPL-3.0-only
set -eu

ROOT=$(CDPATH='' cd "$(dirname "$0")/.." && pwd)
HELPER="$ROOT/scripts/go-proxy-evidence.py"
LOCK="$ROOT/scripts/tesla-proxy-lock.json"
TMP=$(mktemp -d "${TMPDIR:-/tmp}/teslatlas-go-proxy-evidence-test.XXXXXX")
cleanup() {
    chmod -R u+w "$TMP" 2>/dev/null || true
    find "$TMP" -depth -delete 2>/dev/null || true
}
trap cleanup EXIT HUP INT TERM

python3 - "$ROOT" <<'PY'
import copy
import importlib.util
import json
from pathlib import Path
import sys

root = Path(sys.argv[1])
sys.path.insert(0, str(root / "scripts"))
spec = importlib.util.spec_from_file_location(
    "go_proxy_evidence", root / "scripts" / "go-proxy-evidence.py"
)
module = importlib.util.module_from_spec(spec)
assert spec.loader is not None
spec.loader.exec_module(module)
lock = json.loads((root / "scripts" / "tesla-proxy-lock.json").read_text())

assert lock["schema"] == "teslatlas.tesla-proxy-lock/v3"
policy = module.validate_lock(copy.deepcopy(lock))["build_host"]
assert len(policy["go"]) == 3
assert policy["go"] == sorted(
    policy["go"], key=lambda item: (item["path"], item["sha256"], item["goroot"])
)
official = {
    "path": "/Users/bolyki/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.27.0.darwin-arm64/bin/go",
    "sha256": "a19a71df81715c12d9a7e81bab036c12696fec1ddbd4258b48a2131a9080b267",
    "goroot": "/Users/bolyki/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.27.0.darwin-arm64",
}
homebrew = {
    "path": "/opt/homebrew/Cellar/go/1.27.0/libexec/bin/go",
    "sha256": "71c4991041d8e44975c882e4f72005719c958013d3340dc665a3808b72ddf702",
    "goroot": "/opt/homebrew/Cellar/go/1.27.0/libexec",
}
user_owned = {
    "path": "/Users/bolyki/dev/teslatlas-lab/toolchains/go1.27.0-darwin-arm64/bin/go",
    "sha256": "a19a71df81715c12d9a7e81bab036c12696fec1ddbd4258b48a2131a9080b267",
    "goroot": "/Users/bolyki/dev/teslatlas-lab/toolchains/go1.27.0-darwin-arm64",
}
assert official in policy["go"]
assert homebrew in policy["go"]
assert user_owned in policy["go"]

def rejected(action, message):
    try:
        action()
    except module.GateError as error:
        assert message in str(error), (message, str(error))
    else:
        raise AssertionError(f"accepted invalid host policy: {message}")

for selected in (official, homebrew, user_owned):
    observed = {
        "go": copy.deepcopy(selected),
        "compiler": copy.deepcopy(policy["compiler"]),
        "xcode": copy.deepcopy(policy["xcode"]),
        "sdk": copy.deepcopy(policy["sdk"]),
    }
    module.require_reviewed_build_host(observed, policy, "test host")

for field in ("path", "sha256", "goroot"):
    observed = {
        "go": copy.deepcopy(official),
        "compiler": copy.deepcopy(policy["compiler"]),
        "xcode": copy.deepcopy(policy["xcode"]),
        "sdk": copy.deepcopy(policy["sdk"]),
    }
    observed["go"][field] = (
        "0" * 64 if field == "sha256" else observed["go"][field] + ".forged"
    )
    rejected(
        lambda observed=observed: module.require_reviewed_build_host(
            observed, policy, "test host"
        ),
        "Go identity is not an allowed complete binding",
    )

mixed = {
    "go": {
        "path": official["path"],
        "sha256": homebrew["sha256"],
        "goroot": official["goroot"],
    },
    "compiler": copy.deepcopy(policy["compiler"]),
    "xcode": copy.deepcopy(policy["xcode"]),
    "sdk": copy.deepcopy(policy["sdk"]),
}
rejected(
    lambda: module.require_reviewed_build_host(mixed, policy, "test host"),
    "Go identity is not an allowed complete binding",
)

unlisted = copy.deepcopy(mixed)
unlisted["go"] = {
    "path": "/private/reviewed-nowhere/go",
    "sha256": "1" * 64,
    "goroot": "/private/reviewed-nowhere",
}
rejected(
    lambda: module.require_reviewed_build_host(unlisted, policy, "test host"),
    "Go identity is not an allowed complete binding",
)

for section, field in (("compiler", "path"), ("xcode", "build"), ("sdk", "version")):
    observed = {
        "go": copy.deepcopy(official),
        "compiler": copy.deepcopy(policy["compiler"]),
        "xcode": copy.deepcopy(policy["xcode"]),
        "sdk": copy.deepcopy(policy["sdk"]),
    }
    observed[section][field] += ".forged"
    rejected(
        lambda observed=observed: module.require_reviewed_build_host(
            observed, policy, "test host"
        ),
        f"{section} identity does not match the exact lock",
    )

duplicate = copy.deepcopy(lock)
duplicate["build_host"]["go"].append(
    copy.deepcopy(duplicate["build_host"]["go"][0])
)
rejected(lambda: module.validate_lock(duplicate), "duplicate Go host identity")

malformed = copy.deepcopy(lock)
del malformed["build_host"]["go"][0]["goroot"]
rejected(lambda: module.validate_lock(malformed), "keys mismatch")

unsorted = copy.deepcopy(lock)
unsorted["build_host"]["go"].reverse()
rejected(lambda: module.validate_lock(unsorted), "uniquely sorted")
PY

mkdir -p "$TMP/build-cache"
GOCACHE="$TMP/build-cache" \
    "$ROOT/scripts/build-tesla-command-proxy.sh" --target darwin-arm64 \
    --output "$TMP/tesla-http-proxy" \
    >/dev/null
GOCACHE="$TMP/build-cache" \
    "$ROOT/scripts/build-tesla-command-proxy.sh" --target linux-amd64 \
    --output "$TMP/tesla-http-proxy-linux-amd64" >/dev/null
GOCACHE="$TMP/build-cache" \
    "$ROOT/scripts/build-tesla-command-proxy.sh" --target linux-arm64 \
    --output "$TMP/tesla-http-proxy-linux-arm64" >/dev/null

python3 "$HELPER" --repo "$ROOT" --proxy-binary "$TMP/tesla-http-proxy" \
    --output-dir "$TMP/evidence-one" >/dev/null
python3 "$HELPER" --repo "$ROOT" --proxy-binary "$TMP/tesla-http-proxy" \
    --output-dir "$TMP/evidence-two" >/dev/null
python3 "$HELPER" --repo "$ROOT" --target linux-amd64 \
    --proxy-binary "$TMP/tesla-http-proxy-linux-amd64" \
    --output-dir "$TMP/evidence-linux-amd64" >/dev/null
python3 "$HELPER" --repo "$ROOT" --target linux-arm64 \
    --proxy-binary "$TMP/tesla-http-proxy-linux-arm64" \
    --output-dir "$TMP/evidence-linux-arm64" >/dev/null
python3 "$HELPER" --repo "$ROOT" --verify-dir "$TMP/evidence-one" >/dev/null
python3 "$HELPER" --repo "$ROOT" --verify-dir "$TMP/evidence-linux-amd64" >/dev/null
python3 "$HELPER" --repo "$ROOT" --verify-dir "$TMP/evidence-linux-arm64" >/dev/null

for name in \
    GO_THIRD_PARTY_NOTICES.generated.md \
    go-build-receipt.json \
    go-component-manifest.json \
    go-dependency-inventory.json \
    go-sbom.spdx.json \
    tesla-http-proxy.unsigned \
    tesla-http-proxy-go-sources.tar.gz
do
    test -s "$TMP/evidence-one/$name"
    cmp "$TMP/evidence-one/$name" "$TMP/evidence-two/$name"
done

python3 - "$TMP/evidence-one" "$TMP/tesla-http-proxy" <<'PY'
import gzip
import hashlib
import io
import json
from pathlib import Path
import sys
import tarfile

evidence = Path(sys.argv[1])
proxy = Path(sys.argv[2])
digest = lambda data: hashlib.sha256(data).hexdigest()
user_owned = {
    "path": "/Users/bolyki/dev/teslatlas-lab/toolchains/go1.27.0-darwin-arm64/bin/go",
    "sha256": "a19a71df81715c12d9a7e81bab036c12696fec1ddbd4258b48a2131a9080b267",
    "goroot": "/Users/bolyki/dev/teslatlas-lab/toolchains/go1.27.0-darwin-arm64",
}

manifest = json.loads((evidence / "go-component-manifest.json").read_text())
assert manifest["schema"] == "teslatlas.go-proxy-evidence/v2"
assert manifest["target"] == "darwin-arm64"
assert manifest["source_module_count"] == 21
assert manifest["runtime_dependency_count"] == 18
assert manifest["clean_rebuild_byte_identical"] is True
assert manifest["subject"]["sha256"] == digest(proxy.read_bytes())
expected_components = {
    "GO_THIRD_PARTY_NOTICES.generated.md",
    "go-build-receipt.json",
    "go-dependency-inventory.json",
    "go-sbom.spdx.json",
    "tesla-http-proxy.unsigned",
    "tesla-http-proxy-go-sources.tar.gz",
}
assert {item["path"] for item in manifest["components"]} == expected_components
for item in manifest["components"]:
    data = (evidence / item["path"]).read_bytes()
    assert len(data) == item["size"]
    assert digest(data) == item["sha256"]
assert (evidence / "tesla-http-proxy.unsigned").read_bytes() == proxy.read_bytes()

inventory = json.loads((evidence / "go-dependency-inventory.json").read_text())
assert inventory["runtime_dependency_count"] == 20
assert len(inventory["runtime_dependencies"]) == 20
replacement = next(
    item for item in inventory["runtime_dependencies"]
    if item["path"] == "github.com/JuulLabs-OSS/cbgo"
)
assert replacement["replacement"]["path"] == "github.com/tinygo-org/cbgo"

sbom = json.loads((evidence / "go-sbom.spdx.json").read_text())
assert sbom["spdxVersion"] == "SPDX-2.3"
assert len(sbom["packages"]) == 21
assert all(package["licenseDeclared"] != "NOASSERTION" for package in sbom["packages"])

receipt = json.loads((evidence / "go-build-receipt.json").read_text())
assert receipt["clean_rebuild_byte_identical"] is True
assert receipt["target"] == "darwin-arm64"
assert receipt["clean_rebuild_sha256"] == digest(proxy.read_bytes())
assert receipt["strict_go_environment"]["GOFLAGS"] == ""
assert receipt["toolchain"]["go_version"] == "go1.27.0"
assert receipt["toolchain"]["godebug_default"] == "go1.27"
assert "DefaultGODEBUG" not in {
    item["Key"] for item in receipt["build_info"]["Settings"]
}
assert len(receipt["build_host"]["go"]["sha256"]) == 64
assert receipt["build_host"]["go"] == user_owned
assert len(receipt["build_host"]["compiler"]["sha256"]) == 64
assert receipt["build_host"]["go"]["goroot"]
assert receipt["build_host"]["xcode"]["version"].startswith("Xcode ")
assert receipt["build_host"]["sdk"]["version"] == "27.0"
assert receipt["source_configuration"]["archived_upstream_source_unchanged"] is True
assert receipt["source_configuration"]["private_build_copy_go_mod_directive"] == "godebug default=go1.27"
assert receipt["source_configuration"]["overlay_path"] == (
    "packaging/tesla-command-proxy/0001-go-1.27-runtime-defaults.patch"
)
assert len(receipt["source_configuration"]["overlay_sha256"]) == 64
assert len(receipt["source_configuration"]["modified_go_mod_sha256"]) == 64

notice = (evidence / "GO_THIRD_PARTY_NOTICES.generated.md").read_text()
assert notice.count("----- BEGIN EXACT LICENSE TEXT -----") == 22
assert "github.com/tinygo-org/cbgo@v0.0.4" in notice

archive_data = gzip.decompress((evidence / "tesla-http-proxy-go-sources.tar.gz").read_bytes())
with tarfile.open(fileobj=io.BytesIO(archive_data), mode="r:") as archive:
    members = archive.getmembers()
    names = [member.name for member in members]
    assert all(member.isfile() and not member.issym() and member.mtime == 0 for member in members)
    assert len([name for name in names if name.endswith("/module.zip")]) == 21
    assert len([name for name in names if name.endswith("/module.mod")]) == 21
    assert len([name for name in names if name.endswith("/source.json")]) == 21
    assert "tesla-http-proxy-go-sources/tesla-proxy-lock.json" in names
    overlay_name = (
        "tesla-http-proxy-go-sources/packaging/tesla-command-proxy/"
        "0001-go-1.27-runtime-defaults.patch"
    )
    assert overlay_name in names
    assert digest(archive.extractfile(overlay_name).read()) == (
        receipt["source_configuration"]["overlay_sha256"]
    )
    for index in range(21):
        root = f"tesla-http-proxy-go-sources/modules/{index:02d}"
        source = json.load(archive.extractfile(f"{root}/source.json"))
        assert digest(archive.extractfile(f"{root}/module.zip").read()) == source["zip_sha256"]
        assert digest(archive.extractfile(f"{root}/module.mod").read()) == source["go_mod_sha256"]
PY

python3 - \
    "$TMP/evidence-linux-amd64" "$TMP/tesla-http-proxy-linux-amd64" linux-amd64 16 \
    "$TMP/evidence-linux-arm64" "$TMP/tesla-http-proxy-linux-arm64" linux-arm64 16 <<'PY'
import hashlib
import json
from pathlib import Path
import sys

for offset in (1, 5):
    evidence = Path(sys.argv[offset])
    binary = Path(sys.argv[offset + 1])
    target = sys.argv[offset + 2]
    dependency_count = int(sys.argv[offset + 3])
    manifest = json.loads((evidence / "go-component-manifest.json").read_text())
    receipt = json.loads((evidence / "go-build-receipt.json").read_text())
    digest = hashlib.sha256(binary.read_bytes()).hexdigest()
    assert manifest["schema"] == "teslatlas.go-proxy-evidence/v2"
    assert manifest["target"] == target
    assert manifest["subject"]["sha256"] == digest
    assert manifest["subject"]["size"] == binary.stat().st_size
    assert manifest["source_module_count"] == 21
    assert manifest["runtime_dependency_count"] == dependency_count
    assert receipt["target"] == target
    assert receipt["proxy"]["target"] == target
    assert receipt["proxy"]["minimum_macos"] is None
    assert receipt["proxy"]["signature"] == "not applicable to static ELF"
    assert receipt["clean_rebuild_sha256"] == digest
    assert receipt["clean_rebuild_byte_identical"] is True
PY

if python3 "$HELPER" --repo "$ROOT" --target linux-arm64 \
    --proxy-binary "$TMP/tesla-http-proxy-linux-amd64" \
    --output-dir "$TMP/cross-target-evidence" >"$TMP/cross-target.out" 2>&1; then
    echo 'go-proxy-evidence test: cross-target binary was accepted' >&2
    exit 1
fi
grep -Fq 'does not match the reviewed locked subject' "$TMP/cross-target.out"
test ! -e "$TMP/cross-target-evidence"

cp -R "$TMP/evidence-one" "$TMP/mutated-published-evidence"
printf '%s\n' tamper >>"$TMP/mutated-published-evidence/go-build-receipt.json"
if python3 "$HELPER" --repo "$ROOT" \
    --verify-dir "$TMP/mutated-published-evidence" \
    >"$TMP/mutated-published.out" 2>&1; then
    echo 'go-proxy-evidence test: mutated published evidence was accepted' >&2
    exit 1
fi
grep -Fq 'does not match its manifest' "$TMP/mutated-published.out"

python3 - "$TMP/evidence-one" "$TMP" <<'PY'
import hashlib
import json
from pathlib import Path
import shutil
import sys

source = Path(sys.argv[1])
root = Path(sys.argv[2])

def rewrite_manifest(evidence):
    manifest_path = evidence / "go-component-manifest.json"
    manifest = json.loads(manifest_path.read_text())
    for component in manifest["components"]:
        data = (evidence / component["path"]).read_bytes()
        component["sha256"] = hashlib.sha256(data).hexdigest()
        component["size"] = len(data)
    component_set = "".join(
        f"{item['sha256']}  {item['path']}\n"
        for item in sorted(manifest["components"], key=lambda item: item["path"])
    ).encode()
    manifest["component_set_sha256"] = hashlib.sha256(component_set).hexdigest()
    manifest_path.write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2, sort_keys=True) + "\n"
    )

def json_forgery(name, component, mutate):
    evidence = root / name
    shutil.copytree(source, evidence)
    path = evidence / component
    value = json.loads(path.read_text())
    mutate(value)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True) + "\n")
    rewrite_manifest(evidence)

json_forgery(
    "forged-receipt", "go-build-receipt.json",
    lambda value: value.__setitem__("clean_rebuild_sha256", "0" * 64),
)
for field, forged in (
    ("path", "/unreviewed/go"),
    ("sha256", "0" * 64),
    ("goroot", "/unreviewed"),
):
    json_forgery(
        f"forged-go-{field}", "go-build-receipt.json",
        lambda value, field=field, forged=forged: value["build_host"]["go"].__setitem__(
            field, forged
        ),
    )

def mix_allowed_go(value):
    value["build_host"]["go"] = {
        "path": "/Users/bolyki/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.27.0.darwin-arm64/bin/go",
        "sha256": "71c4991041d8e44975c882e4f72005719c958013d3340dc665a3808b72ddf702",
        "goroot": "/Users/bolyki/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.27.0.darwin-arm64",
    }

json_forgery("forged-go-mixed", "go-build-receipt.json", mix_allowed_go)
json_forgery(
    "forged-compiler", "go-build-receipt.json",
    lambda value: value["build_host"]["compiler"].__setitem__("path", "/forged/clang"),
)
json_forgery(
    "forged-xcode", "go-build-receipt.json",
    lambda value: value["build_host"]["xcode"].__setitem__("build", "forged"),
)
json_forgery(
    "forged-sdk", "go-build-receipt.json",
    lambda value: value["build_host"]["sdk"].__setitem__("version", "forged"),
)
json_forgery(
    "forged-inventory", "go-dependency-inventory.json",
    lambda value: value.__setitem__("runtime_dependency_count", 17),
)
json_forgery(
    "forged-sbom", "go-sbom.spdx.json",
    lambda value: value["packages"][0].__setitem__("name", "forged/module"),
)

notices = root / "forged-notices"
shutil.copytree(source, notices)
with (notices / "GO_THIRD_PARTY_NOTICES.generated.md").open("ab") as output:
    output.write(b"forged notice\n")
rewrite_manifest(notices)

archive = root / "forged-archive"
shutil.copytree(source, archive)
with (archive / "tesla-http-proxy-go-sources.tar.gz").open("ab") as output:
    output.write(b"forged archive\n")
rewrite_manifest(archive)

proxy = root / "forged-proxy-component"
shutil.copytree(source, proxy)
with (proxy / "tesla-http-proxy.unsigned").open("ab") as output:
    output.write(b"forged proxy\n")
rewrite_manifest(proxy)

target = root / "forged-target"
shutil.copytree(source, target)
manifest_path = target / "go-component-manifest.json"
manifest = json.loads(manifest_path.read_text())
manifest["target"] = "linux-amd64"
manifest_path.write_text(
    json.dumps(manifest, ensure_ascii=False, indent=2, sort_keys=True) + "\n"
)
PY
for forgery in forged-receipt forged-go-path forged-go-sha256 forged-go-goroot \
    forged-go-mixed forged-compiler forged-xcode forged-sdk forged-inventory \
    forged-sbom forged-notices forged-archive forged-proxy-component forged-target
do
    if python3 "$HELPER" --repo "$ROOT" --verify-dir "$TMP/$forgery" \
        >"$TMP/$forgery.out" 2>&1; then
        echo "go-proxy-evidence test: $forgery was accepted" >&2
        exit 1
    fi
done
grep -Fq 'does not prove the locked reproducible subject' "$TMP/forged-receipt.out"
for forgery in forged-go-path forged-go-sha256 forged-go-goroot forged-go-mixed; do
    grep -Fq 'Go identity is not an allowed complete binding' "$TMP/$forgery.out"
done
grep -Fq 'compiler identity does not match the exact lock' "$TMP/forged-compiler.out"
grep -Fq 'xcode identity does not match the exact lock' "$TMP/forged-xcode.out"
grep -Fq 'sdk identity does not match the exact lock' "$TMP/forged-sdk.out"
grep -Fq 'inventory does not match the exact lock' "$TMP/forged-inventory.out"
grep -Fq 'SBOM does not match the locked source archive' "$TMP/forged-sbom.out"
grep -Fq 'notices do not match the locked source licenses' "$TMP/forged-notices.out"
grep -Eq 'valid gzip stream|canonical reproducible format' "$TMP/forged-archive.out"
grep -Fq 'unsigned Tesla proxy component does not match the locked subject' \
    "$TMP/forged-proxy-component.out"
grep -Fq 'subject does not match the locked proxy' "$TMP/forged-target.out"

cp "$TMP/tesla-http-proxy" "$TMP/tampered-proxy"
printf '%s\n' tamper >>"$TMP/tampered-proxy"
if python3 "$HELPER" --repo "$ROOT" --proxy-binary "$TMP/tampered-proxy" \
    --output-dir "$TMP/tampered-evidence" >"$TMP/tampered.out" 2>&1; then
    echo 'go-proxy-evidence test: tampered binary was accepted' >&2
    exit 1
fi
test ! -e "$TMP/tampered-evidence"

mkdir -p "$TMP/wrong-repo/scripts"
sed 's/"go_version": "go1.27.0"/"go_version": "go1.26.0"/' "$LOCK" \
    >"$TMP/wrong-repo/scripts/tesla-proxy-lock.json"
if python3 "$HELPER" --repo "$TMP/wrong-repo" --proxy-binary "$TMP/tesla-http-proxy" \
    --output-dir "$TMP/wrong-toolchain-evidence" >"$TMP/wrong-toolchain.out" 2>&1; then
    echo 'go-proxy-evidence test: wrong toolchain lock was accepted' >&2
    exit 1
fi
grep -Fq 'reviewed build policy' "$TMP/wrong-toolchain.out"
test ! -e "$TMP/wrong-toolchain-evidence"

ln -s "$TMP/tesla-http-proxy" "$TMP/proxy-link"
if python3 "$HELPER" --repo "$ROOT" --proxy-binary "$TMP/proxy-link" \
    --output-dir "$TMP/symlink-evidence" >"$TMP/symlink.out" 2>&1; then
    echo 'go-proxy-evidence test: symlink proxy was accepted' >&2
    exit 1
fi
grep -Fq 'regular, non-symlink file' "$TMP/symlink.out"
test ! -e "$TMP/symlink-evidence"

mkdir "$TMP/existing-evidence"
printf '%s\n' keep >"$TMP/existing-evidence/marker"
if python3 "$HELPER" --repo "$ROOT" --proxy-binary "$TMP/tesla-http-proxy" \
    --output-dir "$TMP/existing-evidence" >"$TMP/existing.out" 2>&1; then
    echo 'go-proxy-evidence test: existing output was replaced' >&2
    exit 1
fi
test "$(cat "$TMP/existing-evidence/marker")" = keep

printf '%s\n' 'go-proxy-evidence fail-closed test passed'
