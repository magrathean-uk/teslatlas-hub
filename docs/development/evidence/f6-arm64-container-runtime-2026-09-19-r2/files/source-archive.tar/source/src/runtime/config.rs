// SPDX-License-Identifier: AGPL-3.0-only

use std::{
    fmt, fs,
    io::Read,
    net::{IpAddr, Ipv4Addr, SocketAddr},
    os::unix::fs::MetadataExt,
    path::{Path, PathBuf},
    time::Duration,
};

use rustix::{
    fs::{FileType, Mode, OFlags, fcntl_getfl, fcntl_setfl, fstat, open},
    process::getuid,
};
use serde::{Deserialize, Serialize};
use thiserror::Error;
use url::Url;

use crate::{
    owner_api::{OwnerApiBase, OwnerApiOptions},
    protocol::Sha256Digest,
    teslamate::ReadOnlySource,
    teslamate_reader::TeslaMateReadLimits,
};

const MAX_CONFIG_BYTES: usize = 1024 * 1024;
pub(crate) const FLEET_TELEMETRY_INGRESS_PORT: u16 = 8080;

/// The patched Fleet receiver forwards plaintext telemetry to this fixed,
/// private endpoint. It is separate from the configured public Hub listener
/// whenever TLS is enabled.
pub(crate) fn fleet_telemetry_ingress_bind() -> SocketAddr {
    SocketAddr::new(
        IpAddr::V4(Ipv4Addr::LOCALHOST),
        FLEET_TELEMETRY_INGRESS_PORT,
    )
}

fn fleet_telemetry_listener_collides(bind: SocketAddr) -> bool {
    if bind.port() != FLEET_TELEMETRY_INGRESS_PORT {
        return false;
    }
    match bind.ip() {
        IpAddr::V4(address) => address.is_unspecified() || address == Ipv4Addr::LOCALHOST,
        // An IPv6 wildcard may also claim the IPv4 loopback port on platforms
        // with dual-stack sockets, so reject it conservatively.
        IpAddr::V6(address) => address.is_unspecified(),
    }
}

#[derive(Debug, Clone, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct HubConfig {
    pub data_dir: PathBuf,
    pub bind: SocketAddr,
    #[serde(default)]
    pub tls: Option<TlsListenerConfig>,
    #[serde(default)]
    pub collector: CollectorConfig,
    #[serde(default)]
    pub geocoder: GeocoderConfig,
    #[serde(default)]
    pub teslamate: TeslaMateConfig,
    #[serde(default)]
    pub terrain: TerrainConfig,
    #[serde(default)]
    pub http: HttpConfig,
}

/// Browser access is disabled until exact serialized origins are configured.
#[derive(Debug, Clone, Default, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct HttpConfig {
    #[serde(default)]
    pub allowed_origins: Vec<String>,
}

impl HttpConfig {
    pub fn validate(&self) -> Result<(), ConfigError> {
        if self.allowed_origins.len() > 32 {
            return Err(ConfigError::Invalid(
                "http.allowed_origins is limited to 32 origins",
            ));
        }
        let mut seen = std::collections::HashSet::new();
        for origin in &self.allowed_origins {
            let parsed = Url::parse(origin).map_err(|_| {
                ConfigError::Invalid("http.allowed_origins must contain canonical HTTP(S) origins")
            })?;
            if origin.len() > 2048
                || !matches!(parsed.scheme(), "http" | "https")
                || parsed.host_str().is_none()
                || !parsed.username().is_empty()
                || parsed.password().is_some()
                || parsed.query().is_some()
                || parsed.fragment().is_some()
                || parsed.path() != "/"
                || parsed.origin().ascii_serialization() != *origin
                || !seen.insert(origin)
            {
                return Err(ConfigError::Invalid(
                    "http.allowed_origins must contain unique canonical HTTP(S) origins",
                ));
            }
        }
        Ok(())
    }
}

#[derive(Debug, Clone, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct TerrainConfig {
    #[serde(default = "default_terrain_enabled")]
    pub enabled: bool,
    #[serde(default)]
    pub cache_dir: Option<PathBuf>,
    #[serde(default = "default_terrain_min_free_bytes")]
    pub min_free_bytes: u64,
    #[serde(default = "default_terrain_max_cache_bytes")]
    pub max_cache_bytes: u64,
    #[serde(default = "default_terrain_connect_timeout_seconds")]
    pub connect_timeout_seconds: u64,
    #[serde(default = "default_terrain_read_timeout_seconds")]
    pub read_timeout_seconds: u64,
}

const fn default_terrain_enabled() -> bool {
    false
}

fn default_terrain_min_free_bytes() -> u64 {
    128 * 1024 * 1024
}
fn default_terrain_max_cache_bytes() -> u64 {
    512 * 1024 * 1024
}
fn default_terrain_connect_timeout_seconds() -> u64 {
    15
}
fn default_terrain_read_timeout_seconds() -> u64 {
    60
}

impl Default for TerrainConfig {
    fn default() -> Self {
        Self {
            enabled: default_terrain_enabled(),
            cache_dir: None,
            min_free_bytes: default_terrain_min_free_bytes(),
            max_cache_bytes: default_terrain_max_cache_bytes(),
            connect_timeout_seconds: default_terrain_connect_timeout_seconds(),
            read_timeout_seconds: default_terrain_read_timeout_seconds(),
        }
    }
}

impl TerrainConfig {
    pub fn resolved_cache_dir(&self, data_dir: &Path) -> PathBuf {
        if let Some(path) = &self.cache_dir {
            return path.clone();
        }
        #[cfg(target_os = "macos")]
        if let Ok(home) = std::env::var("HOME") {
            return PathBuf::from(home).join("Library/Caches/TeslatlasHub/terrain");
        }
        if let Ok(cache) = std::env::var("XDG_CACHE_HOME") {
            return PathBuf::from(cache).join("teslatlas-hub/terrain");
        }
        data_dir.join("cache/terrain")
    }

    pub fn validate(&self) -> Result<(), ConfigError> {
        if self.min_free_bytes == 0
            || self.max_cache_bytes < crate::terrain::SRTM1_BYTES.saturating_add(16)
            || self.connect_timeout_seconds == 0
            || self.read_timeout_seconds == 0
        {
            return Err(ConfigError::InvalidTerrainConfig);
        }
        Ok(())
    }
}

/// TLS is mandatory for a non-loopback Hub listener. Device pairing and bearer
/// credentials are never sent over plaintext HTTP.
#[derive(Debug, Clone, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct TlsListenerConfig {
    pub certificate_path: PathBuf,
    pub private_key_path: PathBuf,
    pub public_url: String,
}

impl TlsListenerConfig {
    fn validate(&self) -> Result<(), ConfigError> {
        if !self.certificate_path.is_absolute() || !self.private_key_path.is_absolute() {
            return Err(ConfigError::TlsPathMustBeAbsolute);
        }
        if self.certificate_path == self.private_key_path {
            return Err(ConfigError::TlsPathsMustDiffer);
        }
        let endpoint =
            Url::parse(&self.public_url).map_err(|_| ConfigError::InvalidTlsPublicUrl)?;
        if endpoint.scheme() != "https"
            || endpoint.host_str().is_none()
            || endpoint.username() != ""
            || endpoint.password().is_some()
            || endpoint.query().is_some()
            || endpoint.fragment().is_some()
            || endpoint.path() != "/"
        {
            return Err(ConfigError::InvalidTlsPublicUrl);
        }
        Ok(())
    }
}

/// Explicit settings for a manual or supervised legacy owner-token read.
///
/// The default is Tesla's legacy Owner API. A loopback endpoint may override it
/// for local tests. The URL cannot contain credentials or query parameters.
/// Supervised collection runs by default. Set `interval_seconds = 0` to
/// disable it explicitly.
#[derive(Clone, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct CollectorConfig {
    #[serde(default)]
    pub provider: CollectorProvider,
    #[serde(default = "default_owner_api_base_url")]
    pub owner_api_base_url: Option<String>,
    #[serde(default = "default_owner_api_timeout_seconds")]
    pub request_timeout_seconds: u64,
    /// Positive interval for `collect-supervised`; explicit zero disables it.
    #[serde(default = "default_collector_interval_seconds")]
    pub interval_seconds: u64,
    #[serde(default = "default_collector_max_backoff_seconds")]
    pub max_backoff_seconds: u64,
    #[serde(default = "default_driving_poll_milliseconds")]
    pub driving_poll_milliseconds: u64,
    #[serde(default = "default_charging_poll_seconds")]
    pub charging_poll_seconds: u64,
    #[serde(default = "default_online_poll_seconds")]
    pub online_poll_seconds: u64,
    #[serde(default = "default_sleeping_poll_seconds")]
    pub sleeping_poll_seconds: u64,
    #[serde(default = "default_offline_drive_timeout_seconds")]
    pub offline_drive_timeout_seconds: u64,
    #[serde(default = "default_idle_suspend_after_seconds")]
    pub idle_suspend_after_seconds: u64,
    #[serde(default = "default_suspended_poll_seconds")]
    pub suspended_poll_seconds: u64,
    #[serde(default = "default_updating_poll_seconds")]
    pub updating_poll_seconds: u64,
    /// Optional websocket endpoint override. Production overrides must use
    /// wss; ws is accepted only for loopback test endpoints.
    #[serde(default)]
    pub stream_endpoint_override: Option<String>,
    /// Region for provider tokens; absent means derive from the API host.
    #[serde(default)]
    pub stream_region: Option<crate::tesla_stream::StreamRegion>,
    /// Optional loopback Tesla vehicle-command proxy used by Fleet commands.
    /// Fleet wake remains a direct Fleet API call and does not use this proxy.
    #[serde(default)]
    pub fleet_command_proxy_url: Option<String>,
    /// Optional PEM trust root for the loopback Fleet command proxy.
    #[serde(default)]
    pub fleet_command_proxy_root_certificate_path: Option<PathBuf>,
    /// Native Fleet Telemetry receiver configuration. When present, Fleet
    /// collection is push-only and never falls back to paid vehicle-data
    /// polling.
    #[serde(default)]
    pub fleet_telemetry: Option<FleetTelemetryConfig>,
    /// Optional outbound pull consumer for one explicitly bound Edge lineage.
    #[serde(default)]
    pub edge: Option<EdgeCollectorConfig>,
    #[serde(default = "default_stream_health_timeout_seconds")]
    pub stream_health_timeout_seconds: u64,
    /// Enables explicit legacy owner-auth refresh calls. No secret is read
    /// from configuration, and this mode is never used for Fleet TOKEN auth.
    #[serde(default)]
    pub legacy_auth: LegacyAuthConfig,
}

#[derive(Clone, Copy, Debug, Default, Deserialize, Serialize, PartialEq, Eq)]
#[serde(rename_all = "snake_case")]
pub enum CollectorProvider {
    #[default]
    Legacy,
    Fleet,
}

impl fmt::Debug for CollectorConfig {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        formatter
            .debug_struct("CollectorConfig")
            .field("provider", &self.provider)
            .field(
                "owner_api_base_url",
                &self.owner_api_base_url.as_ref().map(|_| "[redacted]"),
            )
            .field("request_timeout_seconds", &self.request_timeout_seconds)
            .field("interval_seconds", &self.interval_seconds)
            .field("max_backoff_seconds", &self.max_backoff_seconds)
            .field("driving_poll_milliseconds", &self.driving_poll_milliseconds)
            .field("charging_poll_seconds", &self.charging_poll_seconds)
            .field("online_poll_seconds", &self.online_poll_seconds)
            .field("sleeping_poll_seconds", &self.sleeping_poll_seconds)
            .field(
                "offline_drive_timeout_seconds",
                &self.offline_drive_timeout_seconds,
            )
            .field(
                "idle_suspend_after_seconds",
                &self.idle_suspend_after_seconds,
            )
            .field("suspended_poll_seconds", &self.suspended_poll_seconds)
            .field("updating_poll_seconds", &self.updating_poll_seconds)
            .field(
                "stream_endpoint_override",
                &self.stream_endpoint_override.as_ref().map(|_| "[redacted]"),
            )
            .field("stream_region", &self.stream_region)
            .field(
                "fleet_command_proxy_url",
                &self.fleet_command_proxy_url.as_ref().map(|_| "[loopback]"),
            )
            .field(
                "fleet_command_proxy_root_certificate_path",
                &self
                    .fleet_command_proxy_root_certificate_path
                    .as_ref()
                    .map(|_| "[configured]"),
            )
            .field(
                "fleet_telemetry",
                &self.fleet_telemetry.as_ref().map(|_| "[configured]"),
            )
            .field("edge", &self.edge.as_ref().map(|_| "[configured]"))
            .field(
                "stream_health_timeout_seconds",
                &self.stream_health_timeout_seconds,
            )
            .field("legacy_auth", &self.legacy_auth)
            .finish()
    }
}

const fn default_owner_api_timeout_seconds() -> u64 {
    20
}

fn default_owner_api_base_url() -> Option<String> {
    Some("https://owner-api.teslamotors.com/".to_owned())
}

const fn default_collector_interval_seconds() -> u64 {
    60
}

const fn default_collector_max_backoff_seconds() -> u64 {
    900
}

const fn default_driving_poll_milliseconds() -> u64 {
    2_500
}

const fn default_charging_poll_seconds() -> u64 {
    5
}

const fn default_online_poll_seconds() -> u64 {
    60
}

const fn default_sleeping_poll_seconds() -> u64 {
    30
}

const fn default_offline_drive_timeout_seconds() -> u64 {
    15 * 60
}

const fn default_idle_suspend_after_seconds() -> u64 {
    15 * 60
}

const fn default_suspended_poll_seconds() -> u64 {
    21 * 60
}

const fn default_updating_poll_seconds() -> u64 {
    15
}

const fn default_stream_health_timeout_seconds() -> u64 {
    30
}

impl Default for CollectorConfig {
    fn default() -> Self {
        Self {
            provider: CollectorProvider::Legacy,
            owner_api_base_url: default_owner_api_base_url(),
            request_timeout_seconds: default_owner_api_timeout_seconds(),
            interval_seconds: default_collector_interval_seconds(),
            max_backoff_seconds: default_collector_max_backoff_seconds(),
            driving_poll_milliseconds: default_driving_poll_milliseconds(),
            charging_poll_seconds: default_charging_poll_seconds(),
            online_poll_seconds: default_online_poll_seconds(),
            sleeping_poll_seconds: default_sleeping_poll_seconds(),
            offline_drive_timeout_seconds: default_offline_drive_timeout_seconds(),
            idle_suspend_after_seconds: default_idle_suspend_after_seconds(),
            suspended_poll_seconds: default_suspended_poll_seconds(),
            updating_poll_seconds: default_updating_poll_seconds(),
            stream_endpoint_override: None,
            stream_region: None,
            fleet_command_proxy_url: None,
            fleet_command_proxy_root_certificate_path: None,
            fleet_telemetry: None,
            edge: None,
            stream_health_timeout_seconds: default_stream_health_timeout_seconds(),
            legacy_auth: LegacyAuthConfig::default(),
        }
    }
}

#[derive(Clone, Deserialize, PartialEq, Eq)]
#[serde(deny_unknown_fields)]
pub struct EdgeCollectorConfig {
    pub base_url: String,
    pub ca_certificate_path: PathBuf,
    pub client_certificate_path: PathBuf,
    pub client_private_key_path: PathBuf,
    pub bearer_token_path: PathBuf,
    pub installation_id: String,
    pub lineage: String,
    pub source_id: uuid::Uuid,
    pub vehicle_id: uuid::Uuid,
    pub vin: String,
    pub car_id: i64,
    #[serde(default = "default_edge_poll_milliseconds")]
    pub poll_milliseconds: u64,
    #[serde(default = "default_edge_timeout_seconds")]
    pub timeout_seconds: u64,
    #[serde(default = "default_edge_max_backoff_seconds")]
    pub max_backoff_seconds: u64,
}

impl fmt::Debug for EdgeCollectorConfig {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        formatter
            .debug_struct("EdgeCollectorConfig")
            .field("base_url", &self.base_url)
            .field("ca_certificate_path", &"[configured]")
            .field("client_certificate_path", &"[configured]")
            .field("client_private_key_path", &"[redacted]")
            .field("bearer_token_path", &"[redacted]")
            .field("installation_id", &self.installation_id)
            .field("lineage", &self.lineage)
            .field("source_id", &self.source_id)
            .field("vehicle_id", &self.vehicle_id)
            .field("vin", &self.vin)
            .field("car_id", &self.car_id)
            .field("poll_milliseconds", &self.poll_milliseconds)
            .field("timeout_seconds", &self.timeout_seconds)
            .field("max_backoff_seconds", &self.max_backoff_seconds)
            .finish()
    }
}

const fn default_edge_poll_milliseconds() -> u64 {
    500
}
const fn default_edge_timeout_seconds() -> u64 {
    20
}
const fn default_edge_max_backoff_seconds() -> u64 {
    60
}

impl EdgeCollectorConfig {
    fn validate(&self) -> Result<(), ConfigError> {
        let endpoint = Url::parse(&self.base_url).map_err(|_| ConfigError::InvalidEdge)?;
        if endpoint.scheme() != "https"
            || endpoint.host_str().is_none()
            || !endpoint.username().is_empty()
            || endpoint.password().is_some()
            || endpoint.query().is_some()
            || endpoint.fragment().is_some()
            || endpoint.path() != "/"
            || self.source_id.is_nil()
            || self.vehicle_id.is_nil()
            || self.car_id <= 0
            || self.poll_milliseconds == 0
            || self.timeout_seconds == 0
            || self.max_backoff_seconds == 0
            || self.installation_id.is_empty()
            || self.installation_id.len() > 128
            || self.lineage.is_empty()
            || self.lineage.len() > 128
            || self.vin.len() != 17
            || !self.vin.bytes().all(|byte| byte.is_ascii_alphanumeric())
            || self
                .vin
                .bytes()
                .any(|byte| matches!(byte, b'I' | b'O' | b'Q'))
            || !self.installation_id.bytes().all(|byte| {
                byte.is_ascii_lowercase()
                    || byte.is_ascii_digit()
                    || matches!(byte, b'.' | b'_' | b'-')
            })
            || !self.lineage.bytes().all(|byte| {
                byte.is_ascii_lowercase()
                    || byte.is_ascii_digit()
                    || matches!(byte, b'.' | b'_' | b'-')
            })
        {
            return Err(ConfigError::InvalidEdge);
        }
        let paths = [
            &self.ca_certificate_path,
            &self.client_certificate_path,
            &self.client_private_key_path,
            &self.bearer_token_path,
        ];
        if paths.iter().any(|path| !path.is_absolute())
            || paths
                .iter()
                .enumerate()
                .any(|(index, path)| paths[index + 1..].contains(path))
        {
            return Err(ConfigError::InvalidEdge);
        }
        Ok(())
    }
}

/// Public Tesla Fleet Telemetry endpoint and its local Hub ingress secret.
///
/// The hostname is sent to the vehicle. TLS termination happens in the
/// companion receiver; the Rust Hub uses the fixed private loopback ingress
/// alongside its configured public TLS listener when both are enabled.
#[derive(Clone, Deserialize, PartialEq, Eq)]
#[serde(deny_unknown_fields)]
pub struct FleetTelemetryConfig {
    pub hostname: String,
    #[serde(default = "default_fleet_telemetry_port")]
    pub port: u16,
    pub ca_certificate_path: PathBuf,
    pub ingest_token_path: PathBuf,
}

impl fmt::Debug for FleetTelemetryConfig {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        formatter
            .debug_struct("FleetTelemetryConfig")
            .field("hostname", &self.hostname)
            .field("port", &self.port)
            .field("ca_certificate_path", &"[configured]")
            .field("ingest_token_path", &"[redacted]")
            .finish()
    }
}

const fn default_fleet_telemetry_port() -> u16 {
    443
}

impl FleetTelemetryConfig {
    fn validate(&self) -> Result<(), ConfigError> {
        let hostname = self.hostname.as_str();
        let hostname_valid = !hostname.is_empty()
            && hostname.len() <= 253
            && hostname.is_ascii()
            && !hostname.starts_with('.')
            && !hostname.ends_with('.')
            && hostname.split('.').all(|label| {
                !label.is_empty()
                    && label.len() <= 63
                    && !label.starts_with('-')
                    && !label.ends_with('-')
                    && label
                        .bytes()
                        .all(|byte| byte.is_ascii_alphanumeric() || byte == b'-')
            });
        if !hostname_valid || self.port == 0 {
            return Err(ConfigError::InvalidFleetTelemetry);
        }
        if !self.ca_certificate_path.is_absolute()
            || !self.ingest_token_path.is_absolute()
            || self.ca_certificate_path == self.ingest_token_path
        {
            return Err(ConfigError::InvalidFleetTelemetry);
        }
        Ok(())
    }
}

#[derive(Debug, Clone, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct LegacyAuthConfig {
    #[serde(default)]
    pub enabled: bool,
}

impl Default for LegacyAuthConfig {
    fn default() -> Self {
        Self { enabled: true }
    }
}

#[derive(Debug, Clone, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct GeocoderConfig {
    #[serde(default = "default_geocoder_enabled")]
    pub enabled: bool,
    #[serde(default)]
    pub endpoint: Option<String>,
    #[serde(default = "default_geocoder_language")]
    pub language: String,
    #[serde(default = "default_geocoder_timeout_seconds")]
    pub timeout_seconds: u64,
}

impl Default for GeocoderConfig {
    fn default() -> Self {
        Self {
            enabled: default_geocoder_enabled(),
            endpoint: None,
            language: default_geocoder_language(),
            timeout_seconds: default_geocoder_timeout_seconds(),
        }
    }
}

const fn default_geocoder_enabled() -> bool {
    false
}

impl GeocoderConfig {
    pub(crate) fn endpoint_url(&self, test_mode: bool) -> Result<Url, ConfigError> {
        let raw = self
            .endpoint
            .as_deref()
            .ok_or(ConfigError::InvalidGeocoderEndpoint)?;
        let mut endpoint = Url::parse(raw).map_err(|_| ConfigError::InvalidGeocoderEndpoint)?;
        if endpoint.host_str().is_none()
            || !matches!(endpoint.scheme(), "https" | "http")
            || (!test_mode && endpoint.scheme() != "https")
            || !endpoint.username().is_empty()
            || endpoint.password().is_some()
            || endpoint.query().is_some()
            || endpoint.fragment().is_some()
        {
            return Err(ConfigError::InvalidGeocoderEndpoint);
        }
        if !endpoint.path().ends_with('/') {
            endpoint.set_path(&format!("{}/", endpoint.path()));
        }
        Ok(endpoint)
    }

    pub(crate) fn timeout(&self) -> Result<Duration, ConfigError> {
        if self.timeout_seconds == 0 || self.timeout_seconds > 120 {
            return Err(ConfigError::InvalidGeocoderTimeout);
        }
        Ok(Duration::from_secs(self.timeout_seconds))
    }

    pub(crate) fn validated_language(&self) -> Result<String, ConfigError> {
        if self.language.is_empty()
            || self.language.len() > 64
            || self.language.chars().any(char::is_control)
        {
            return Err(ConfigError::InvalidGeocoderLanguage);
        }
        Ok(self.language.clone())
    }
}

fn default_geocoder_language() -> String {
    "en".to_owned()
}

const fn default_geocoder_timeout_seconds() -> u64 {
    30
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct CollectorCadence {
    pub driving: Duration,
    pub charging: Duration,
    pub online: Duration,
    pub sleeping: Duration,
    pub offline_drive_timeout: Duration,
    pub idle_suspend_after: Duration,
    pub suspended: Duration,
    pub updating: Duration,
    pub stream_health_timeout: Duration,
    pub maximum_backoff: Duration,
}

impl CollectorConfig {
    pub fn owner_api_options(&self) -> Result<OwnerApiOptions, ConfigError> {
        self.owner_api_options_for_region(crate::tesla_stream::StreamRegion::Global)
    }

    /// Resolve the legacy Owner API endpoint for the token's region. The
    /// canonical global default is provider-selected for China tokens; an
    /// explicit custom endpoint always wins.
    pub fn owner_api_options_for_region(
        &self,
        region: crate::tesla_stream::StreamRegion,
    ) -> Result<OwnerApiOptions, ConfigError> {
        let base_url = self
            .owner_api_base_url
            .as_deref()
            .ok_or(ConfigError::OwnerApiBaseRequired)?;
        let mut base_url =
            OwnerApiBase::parse(base_url).map_err(|_| ConfigError::InvalidOwnerApiBase)?;
        if region == crate::tesla_stream::StreamRegion::China
            && base_url
                == OwnerApiBase::parse("https://owner-api.teslamotors.com/")
                    .map_err(|_| ConfigError::InvalidOwnerApiBase)?
        {
            base_url = OwnerApiBase::parse("https://owner-api.vn.cloud.tesla.cn/")
                .map_err(|_| ConfigError::InvalidOwnerApiBase)?;
        }
        let request_timeout = Duration::from_secs(self.request_timeout_seconds);
        if request_timeout.is_zero() {
            return Err(ConfigError::InvalidOwnerApiTimeout);
        }
        Ok(OwnerApiOptions::new(base_url, request_timeout))
    }

    pub fn supervised_interval(&self) -> Result<Duration, ConfigError> {
        if self.interval_seconds == 0 {
            return Err(ConfigError::SupervisedIntervalRequired);
        }
        Ok(Duration::from_secs(self.interval_seconds))
    }

    pub fn cadence(&self) -> Result<CollectorCadence, ConfigError> {
        let cadence = CollectorCadence {
            driving: Duration::from_millis(self.driving_poll_milliseconds),
            charging: Duration::from_secs(self.charging_poll_seconds),
            online: Duration::from_secs(self.online_poll_seconds),
            sleeping: Duration::from_secs(self.sleeping_poll_seconds),
            offline_drive_timeout: Duration::from_secs(self.offline_drive_timeout_seconds),
            idle_suspend_after: Duration::from_secs(self.idle_suspend_after_seconds),
            suspended: Duration::from_secs(self.suspended_poll_seconds),
            updating: Duration::from_secs(self.updating_poll_seconds),
            stream_health_timeout: Duration::from_secs(self.stream_health_timeout_seconds),
            maximum_backoff: Duration::from_secs(self.max_backoff_seconds),
        };
        if cadence.driving.is_zero()
            || cadence.charging.is_zero()
            || cadence.online.is_zero()
            || cadence.sleeping.is_zero()
            || cadence.offline_drive_timeout.is_zero()
            || cadence.idle_suspend_after.is_zero()
            || cadence.suspended.is_zero()
            || cadence.updating.is_zero()
            || cadence.stream_health_timeout.is_zero()
            || cadence.maximum_backoff.is_zero()
        {
            return Err(ConfigError::InvalidCollectorCadence);
        }
        Ok(cadence)
    }

    pub fn stream_endpoint(
        &self,
        region: crate::tesla_stream::StreamRegion,
    ) -> Result<String, ConfigError> {
        if let Some(override_url) = &self.stream_endpoint_override {
            crate::tesla_stream::validate_endpoint_override(override_url)
                .map_err(|_| ConfigError::InvalidStreamEndpoint)?;
            return Ok(override_url.clone());
        }
        Ok(crate::tesla_stream::streaming_endpoint(region).to_owned())
    }

    pub fn stream_region(&self) -> Result<crate::tesla_stream::StreamRegion, ConfigError> {
        if let Some(region) = self.stream_region {
            return Ok(region);
        }
        let base = self
            .owner_api_base_url
            .as_deref()
            .ok_or(ConfigError::StreamRegionRequired)?;
        OwnerApiBase::parse(base)
            .map_err(|_| ConfigError::InvalidOwnerApiBase)?
            .stream_region()
            .ok_or(ConfigError::StreamRegionRequired)
    }
}

/// Opt-in TeslaMate import source. The endpoint excludes its password and the
/// source key is a durable owner label, not an endpoint alias.
#[derive(Clone, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct TeslaMateConfig {
    #[serde(default)]
    pub source_url: Option<String>,
    #[serde(default)]
    pub source_key: Option<String>,
    #[serde(default = "default_teslamate_connect_timeout_seconds")]
    pub connect_timeout_seconds: u64,
    #[serde(default = "default_teslamate_copy_statement_timeout_seconds")]
    pub copy_statement_timeout_seconds: u64,
    #[serde(default = "default_teslamate_page_size")]
    pub page_size: i32,
    #[serde(default = "default_teslamate_maximum_rows")]
    pub maximum_rows: usize,
    #[serde(default = "default_teslamate_maximum_stage_bytes")]
    pub maximum_stage_bytes: u64,
    #[serde(default = "default_teslamate_minimum_free_bytes")]
    pub minimum_free_bytes: u64,
    #[serde(default = "default_teslamate_parallel_copy_lanes")]
    pub parallel_copy_lanes: usize,
    #[serde(default)]
    pub performance_profile: PerformanceProfileConfig,
}

impl fmt::Debug for TeslaMateConfig {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        formatter
            .debug_struct("TeslaMateConfig")
            .field(
                "source_url",
                &self.source_url.as_ref().map(|_| "[redacted]"),
            )
            .field("source_key", &self.source_key)
            .field("connect_timeout_seconds", &self.connect_timeout_seconds)
            .field(
                "copy_statement_timeout_seconds",
                &self.copy_statement_timeout_seconds,
            )
            .field("page_size", &self.page_size)
            .field("maximum_rows", &self.maximum_rows)
            .field("maximum_stage_bytes", &self.maximum_stage_bytes)
            .field("minimum_free_bytes", &self.minimum_free_bytes)
            .field("parallel_copy_lanes", &self.parallel_copy_lanes)
            .field("performance_profile", &self.performance_profile)
            .finish()
    }
}

/// Conservative host-local tuning for the TeslaMate import reader.
#[derive(Debug, Clone, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct PerformanceProfileConfig {
    #[serde(default = "default_performance_profile_enabled")]
    pub enabled: bool,
    #[serde(default)]
    pub max_parallel_copy_lanes: Option<usize>,
}

const fn default_performance_profile_enabled() -> bool {
    true
}

impl Default for PerformanceProfileConfig {
    fn default() -> Self {
        Self {
            enabled: default_performance_profile_enabled(),
            max_parallel_copy_lanes: None,
        }
    }
}

const fn default_teslamate_connect_timeout_seconds() -> u64 {
    10
}

const fn default_teslamate_copy_statement_timeout_seconds() -> u64 {
    2 * 60 * 60
}

const fn default_teslamate_page_size() -> i32 {
    10_000
}

const fn default_teslamate_maximum_rows() -> usize {
    20_000_000
}

const fn default_teslamate_maximum_stage_bytes() -> u64 {
    16 * 1024 * 1024 * 1024
}

const fn default_teslamate_minimum_free_bytes() -> u64 {
    512 * 1024 * 1024
}

const fn default_teslamate_parallel_copy_lanes() -> usize {
    4
}

impl Default for TeslaMateConfig {
    fn default() -> Self {
        Self {
            source_url: None,
            source_key: None,
            connect_timeout_seconds: default_teslamate_connect_timeout_seconds(),
            copy_statement_timeout_seconds: default_teslamate_copy_statement_timeout_seconds(),
            page_size: default_teslamate_page_size(),
            maximum_rows: default_teslamate_maximum_rows(),
            maximum_stage_bytes: default_teslamate_maximum_stage_bytes(),
            minimum_free_bytes: default_teslamate_minimum_free_bytes(),
            parallel_copy_lanes: default_teslamate_parallel_copy_lanes(),
            performance_profile: PerformanceProfileConfig::default(),
        }
    }
}

#[derive(Clone)]
pub struct TeslaMateImportConfig {
    pub source: ReadOnlySource,
    pub source_key: String,
    pub limits: TeslaMateReadLimits,
    pub performance_profile: PerformanceProfileConfig,
}

impl fmt::Debug for TeslaMateImportConfig {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        formatter
            .debug_struct("TeslaMateImportConfig")
            .field("source", &self.source)
            .field("source_key", &self.source_key)
            .field("limits", &self.limits)
            .field("performance_profile", &self.performance_profile)
            .finish()
    }
}

impl TeslaMateConfig {
    /// Build and validate source-read limits for both configured and CLI
    /// supplied TeslaMate sources. Source URL/key are intentionally separate.
    pub fn read_limits(&self) -> Result<TeslaMateReadLimits, ConfigError> {
        let limits = TeslaMateReadLimits {
            connect_timeout: Duration::from_secs(self.connect_timeout_seconds),
            copy_statement_timeout: Duration::from_secs(self.copy_statement_timeout_seconds),
            page_size: self.page_size,
            maximum_rows: self.maximum_rows,
            maximum_stage_bytes: self.maximum_stage_bytes,
            minimum_free_bytes: self.minimum_free_bytes,
            parallel_copy_lanes: self.parallel_copy_lanes,
        };
        limits
            .validate()
            .map_err(|_| ConfigError::InvalidTeslaMateLimits)?;

        let maximum = self.performance_profile.max_parallel_copy_lanes;
        if let Some(maximum) = maximum {
            let mut validation_probe = limits;
            validation_probe.parallel_copy_lanes = maximum;
            validation_probe
                .validate()
                .map_err(|_| ConfigError::InvalidTeslaMateLimits)?;
        }
        if !self.performance_profile.enabled {
            return Ok(limits);
        }

        let mut effective = limits;
        if let Some(maximum) = maximum {
            effective.parallel_copy_lanes = effective.parallel_copy_lanes.min(maximum);
        }
        Ok(effective)
    }

    pub fn import_config(&self) -> Result<TeslaMateImportConfig, ConfigError> {
        let source_url = self
            .source_url
            .as_deref()
            .ok_or(ConfigError::TeslaMateSourceRequired)?;
        let source =
            ReadOnlySource::parse(source_url).map_err(|_| ConfigError::InvalidTeslaMateSource)?;
        let source_key = self
            .source_key
            .as_deref()
            .filter(|value| !value.is_empty())
            .ok_or(ConfigError::TeslaMateSourceKeyRequired)?;
        if source_key.contains("://")
            || source_key.contains('@')
            || source_key.chars().any(char::is_control)
        {
            return Err(ConfigError::InvalidTeslaMateSourceKey);
        }
        let limits = self.read_limits()?;
        Ok(TeslaMateImportConfig {
            source,
            source_key: source_key.to_owned(),
            limits,
            performance_profile: self.performance_profile.clone(),
        })
    }
}

impl HubConfig {
    pub fn load(path: impl AsRef<Path>) -> Result<Self, ConfigError> {
        Self::load_with_digest(path).map(|(config, _digest)| config)
    }

    /// Reads, parses, validates, and hashes one exact configuration snapshot.
    /// The returned digest therefore identifies the bytes that produced the
    /// in-memory configuration rather than a second, racy filesystem read.
    pub fn load_with_digest(path: impl AsRef<Path>) -> Result<(Self, Sha256Digest), ConfigError> {
        let source = read_config_file(path.as_ref())?;
        Self::from_exact_bytes(&source)
    }

    /// Parses and validates the one exact configuration byte sequence supplied
    /// by the caller.  This is deliberately shared with `load_with_digest` so
    /// callers that hold an already-admitted descriptor do not need to reopen
    /// a pathname merely to preserve ordinary configuration semantics.
    pub fn from_exact_bytes(source: &[u8]) -> Result<(Self, Sha256Digest), ConfigError> {
        let source = std::str::from_utf8(source)
            .map_err(|_| ConfigError::Invalid("configuration must be UTF-8"))?;
        let digest = Sha256Digest::of_bytes(source.as_bytes());
        let config: Self = toml::from_str(source).map_err(ConfigError::Parse)?;
        config.validate()?;
        Ok((config, digest))
    }

    pub fn validate(&self) -> Result<(), ConfigError> {
        if self.data_dir.as_os_str().is_empty() {
            return Err(ConfigError::Invalid("data_dir is required"));
        }
        if !self.data_dir.is_absolute() {
            return Err(ConfigError::Invalid("data_dir must be absolute"));
        }
        if self.bind.port() == 0 {
            return Err(ConfigError::Invalid("bind port must not be zero"));
        }
        if !self.bind.ip().is_loopback() && self.tls.is_none() {
            return Err(ConfigError::NonLoopbackBind);
        }
        if let Some(tls) = &self.tls {
            tls.validate()?;
        }
        self.http.validate()?;
        if self.collector.request_timeout_seconds == 0 {
            return Err(ConfigError::InvalidOwnerApiTimeout);
        }
        if self.geocoder.enabled || self.geocoder.endpoint.is_some() {
            self.geocoder.endpoint_url(false)?;
        }
        self.geocoder.timeout()?;
        self.geocoder.validated_language()?;
        self.terrain.validate()?;
        self.collector.cadence()?;
        if let Some(base_url) = self.collector.owner_api_base_url.as_deref() {
            OwnerApiBase::parse(base_url).map_err(|_| ConfigError::InvalidOwnerApiBase)?;
        }
        if self.collector.legacy_auth.enabled && self.collector.owner_api_base_url.is_none() {
            return Err(ConfigError::OwnerApiBaseRequired);
        }
        if let Some(endpoint) = self.collector.stream_endpoint_override.as_deref() {
            crate::tesla_stream::validate_endpoint_override(endpoint)
                .map_err(|_| ConfigError::InvalidStreamEndpoint)?;
        }
        if let Some(endpoint) = self.collector.fleet_command_proxy_url.as_deref() {
            crate::fleet_api::FleetCommandProxyBase::parse(endpoint)
                .map_err(|_| ConfigError::InvalidFleetCommandProxy)?;
        }
        if let Some(path) = self
            .collector
            .fleet_command_proxy_root_certificate_path
            .as_deref()
            && (!path.is_absolute() || self.collector.fleet_command_proxy_url.is_none())
        {
            return Err(ConfigError::InvalidFleetCommandProxy);
        }
        if let Some(telemetry) = &self.collector.fleet_telemetry {
            telemetry.validate()?;
            if self.collector.provider != CollectorProvider::Fleet
                || self.collector.fleet_command_proxy_url.is_none()
            {
                return Err(ConfigError::InvalidFleetTelemetry);
            }
            if let Some(_tls) = &self.tls {
                if fleet_telemetry_listener_collides(self.bind) {
                    return Err(ConfigError::FleetTelemetryListenerCollision);
                }
            } else if self.bind != fleet_telemetry_ingress_bind() {
                return Err(ConfigError::InvalidFleetTelemetry);
            }
        }
        if let Some(edge) = &self.collector.edge {
            edge.validate()?;
            if self.collector.provider != CollectorProvider::Fleet
                || self.collector.interval_seconds != 0
                || self.collector.fleet_telemetry.is_some()
            {
                return Err(ConfigError::InvalidEdge);
            }
        }
        let source_set = self.teslamate.source_url.is_some();
        let source_key_set = self.teslamate.source_key.is_some();
        if source_set != source_key_set {
            return Err(ConfigError::TeslaMatePartialConfiguration);
        }
        if source_set {
            self.teslamate.import_config()?;
        }
        Ok(())
    }

    pub fn database_path(&self) -> PathBuf {
        self.data_dir.join("hub.sqlite")
    }

    pub fn packs_dir(&self) -> PathBuf {
        self.data_dir.join("packs")
    }
}

fn read_config_file(path: &Path) -> Result<Vec<u8>, ConfigError> {
    read_config_file_after_open(path, || {})
}

fn read_config_file_after_open(
    path: &Path,
    after_open: impl FnOnce(),
) -> Result<Vec<u8>, ConfigError> {
    let descriptor = open(
        path,
        OFlags::RDONLY | OFlags::NOFOLLOW | OFlags::CLOEXEC | OFlags::NONBLOCK,
        Mode::empty(),
    )
    .map_err(|_| ConfigError::Read)?;
    let held = fstat(&descriptor).map_err(|_| ConfigError::Read)?;
    if !FileType::from_raw_mode(held.st_mode).is_file()
        || (held.st_uid != getuid().as_raw() && held.st_uid != 0)
        || (held.st_mode as u32 & 0o022) != 0
    {
        return Err(ConfigError::UnsafeFile);
    }
    let flags = fcntl_getfl(&descriptor).map_err(|_| ConfigError::Read)?;
    fcntl_setfl(&descriptor, flags & !OFlags::NONBLOCK).map_err(|_| ConfigError::Read)?;

    after_open();

    let file: fs::File = descriptor.into();
    let mut source = Vec::with_capacity(MAX_CONFIG_BYTES.min(8 * 1024));
    file.take(u64::try_from(MAX_CONFIG_BYTES + 1).expect("config cap fits u64"))
        .read_to_end(&mut source)
        .map_err(|_| ConfigError::Read)?;
    if source.len() > MAX_CONFIG_BYTES {
        return Err(ConfigError::TooLarge);
    }

    let current = fs::symlink_metadata(path).map_err(|_| ConfigError::Read)?;
    if current.file_type().is_symlink()
        || !current.file_type().is_file()
        || current.uid() != held.st_uid
        || current.dev() != held.st_dev as u64
        || current.ino() != held.st_ino
        || (current.mode() & 0o022) != 0
    {
        return Err(ConfigError::FileIdentityChanged);
    }
    Ok(source)
}

#[derive(Debug, Error)]
pub enum ConfigError {
    #[error("cannot safely read configuration")]
    Read,
    #[error("configuration exceeds the fixed size limit")]
    TooLarge,
    #[error("configuration file is unsafe")]
    UnsafeFile,
    #[error("configuration file identity changed while reading")]
    FileIdentityChanged,
    #[error("invalid configuration: {0}")]
    Parse(toml::de::Error),
    #[error("invalid configuration: {0}")]
    Invalid(&'static str),
    #[error("collector owner API base URL is required for manual collection")]
    OwnerApiBaseRequired,
    #[error("collector owner API base URL is invalid")]
    InvalidOwnerApiBase,
    #[error("collector owner API timeout must be greater than zero")]
    InvalidOwnerApiTimeout,
    #[error("stream region must be explicit or derivable from the owner API host")]
    StreamRegionRequired,
    #[error("stream endpoint override is invalid or unsafe")]
    InvalidStreamEndpoint,
    #[error("Fleet command proxy configuration is invalid or unsafe")]
    InvalidFleetCommandProxy,
    #[error("Fleet Telemetry configuration is invalid or unsafe")]
    InvalidFleetTelemetry,
    #[error(
        "Fleet Telemetry private ingress uses 127.0.0.1:8080; choose another TLS bind address or port"
    )]
    FleetTelemetryListenerCollision,
    #[error(
        "Edge collector configuration is invalid or conflicts with another ingestion authority"
    )]
    InvalidEdge,
    #[error("geocoder endpoint is invalid or unsafe")]
    InvalidGeocoderEndpoint,
    #[error("geocoder language is invalid")]
    InvalidGeocoderLanguage,
    #[error("geocoder timeout is invalid")]
    InvalidGeocoderTimeout,
    #[error("terrain cache configuration is invalid")]
    InvalidTerrainConfig,
    #[error("supervised collector requires an explicit interval_seconds")]
    SupervisedIntervalRequired,
    #[error("collector cadence values must be greater than zero")]
    InvalidCollectorCadence,
    #[error("non-loopback bind requires configured TLS")]
    NonLoopbackBind,
    #[error("TLS certificate and private-key paths must be absolute")]
    TlsPathMustBeAbsolute,
    #[error("TLS certificate and private-key paths must differ")]
    TlsPathsMustDiffer,
    #[error("TLS public_url must be an origin-only HTTPS URL without credentials")]
    InvalidTlsPublicUrl,
    #[error("TeslaMate source URL and source key must be configured together")]
    TeslaMatePartialConfiguration,
    #[error("TeslaMate source URL is required for import")]
    TeslaMateSourceRequired,
    #[error("TeslaMate source URL is invalid")]
    InvalidTeslaMateSource,
    #[error("TeslaMate source key is required for import")]
    TeslaMateSourceKeyRequired,
    #[error("TeslaMate source key must be an opaque non-secret label")]
    InvalidTeslaMateSourceKey,
    #[error("TeslaMate import limits are invalid")]
    InvalidTeslaMateLimits,
}

#[cfg(test)]
#[path = "config/tests.rs"]
mod tests;
